/* Node 驗證：用真實來源檔跑 二(1) 產生，並比對參考月報 */
const fs = require('fs');
const path = require('path');
const ExcelJS = require(process.env.NM + '/exceljs');
const XLSX = require(process.env.NM + '/xlsx');
require('./core.js');

const DIR = path.resolve(__dirname, '..'); // 月報表 資料夾
function ab(p) { const b = fs.readFileSync(path.join(DIR, p)); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); }

(async () => {
  const inputs = {
    tpl21: ab('二(1).115年○月醫療品質指標月報(TCPI.QIP).xlsx'),
    src1: ab('一(1).個別群組報表(綜合).xls'),
    src2: ab('一(2).個別群組報表(精神).xls'),
    src3: ab('一(3).月指標_臨床指標-115-○(月).xlsx'),
  };
  const out = await MonthlyReport.generate({ ExcelJS, XLSX }, inputs);
  console.log('--- LOG ---'); out.log.forEach(l => console.log(' ', l));
  console.log('\n紅燈項目 (' + out.results.red.length + '):');
  out.results.red.forEach(r => console.log('   [' + r.sheet + '] ' + r.code + ' ' + String(r.name).slice(0,18) + ' 數值=' + r.val + ' 閾值=' + r.threshold + ' → ' + r.light));
  console.log('\n黃燈項目 (' + out.results.yellow.length + '):');
  out.results.yellow.forEach(r => console.log('   [' + r.sheet + '] ' + r.code + ' ' + String(r.name).slice(0,18) + ' 數值=' + r.val + ' 目標=' + r.threshold + ' → ' + r.light));
  console.log('\n查無來源之指標 (' + out.results.notFound.length + '): ' + out.results.notFound.slice(0,10).join(' | '));

  // 寫出產生的檔案
  fs.writeFileSync(path.join(__dirname, 'out_二1.xlsx'), Buffer.from(out.xlsxBuffer));
  console.log('\n已輸出 code/out_二1.xlsx');
})();
