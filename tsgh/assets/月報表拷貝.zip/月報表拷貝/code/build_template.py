# -*- coding: utf-8 -*-
"""以「真實 二(2).docx」改造成 docxtemplater 模板，完整保留原字體/顏色/表格底色/框線。
   作法：每個表格保留 表頭列 + 一個「構面列(合併)」+ 一個「明細列」，改寫其文字為標記，刪除其餘資料列。
"""
import os
from docx import Document

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'

def set_cell_tag(cell, tag):
    """保留該格第一個 run 的格式，只換文字；移除多餘 run。"""
    p = cell.paragraphs[0]
    runs = p.runs
    if runs:
        runs[0].text = tag
        for r in runs[1:]:
            r._element.getparent().remove(r._element)
    else:
        p.add_run(tag)
    # 若同格有多段落，清掉後續段落文字
    for extra in cell.paragraphs[1:]:
        for r in list(extra.runs):
            r._element.getparent().remove(r._element)

def remove_row(table, row):
    row._tr.getparent().remove(row._tr)

SRC = os.path.join(os.path.dirname(__file__), '..', '二(2).115年○月份醫療品質指標監測摘要表.docx')
doc = Document(SRC)

# 明細列 10 欄對應標記（items 迴圈）。第1欄同時開 groups+items，末欄收 items+groups。
def build(table, loop):
    # row0 = 表頭（保留）；row1 = 構面列(合併,1格)；row2 = 首筆明細列
    cat_cell = table.rows[1].cells[0]
    set_cell_tag(cat_cell, '{#%s}{cat}' % loop)
    data = table.rows[2]
    tags = ['{#items}{idx}', '{name}', '{unit}', '{dir}', '{uom}',
            '{num}', '{den}', '{val}', '{threshold}', '{note}{/items}{/%s}' % loop]
    # data 列的實際 cell 數（含合併）以 tc 數為準
    tcs = data._tr.findall(W + 'tc')
    for i, tc in enumerate(tcs):
        if i >= len(tags):
            break
        # 取該 tc 對應的 cell 物件
        cell = data.cells[i] if i < len(data.cells) else None
        if cell is not None:
            set_cell_tag(cell, tags[i])
    # 刪除 row index >=3 的所有資料/構面列
    for row in list(table.rows[3:]):
        remove_row(table, row)

build(doc.tables[0], 'redGroups')     # 紅燈表（第9欄=閾值）
build(doc.tables[1], 'yellowGroups')  # 黃燈表（第9欄=目標值）

os.makedirs(os.path.join(os.path.dirname(__file__), 'templates'), exist_ok=True)
outp = os.path.join(os.path.dirname(__file__), 'templates', '摘要表_template.docx')
doc.save(outp)
print('saved', outp)

# 檢查標記是否正確落位
chk = Document(outp)
for ti, tb in enumerate(chk.tables):
    print(f'表{ti}: {len(tb.rows)}列')
    print('  構面列:', tb.rows[1].cells[0].text)
    print('  明細列:', [c.text for c in tb.rows[2].cells[:10]])
