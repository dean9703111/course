const fs=require('fs'), path=require('path');
const ExcelJS=require(process.env.NM+'/exceljs'), XLSX=require(process.env.NM+'/xlsx');
const PizZip=require(process.env.NM+'/pizzip'), Docxtemplater=require(process.env.NM+'/docxtemplater');
require('./core.js');
const DIR=path.resolve(__dirname,'..');
function ab(p){const b=fs.readFileSync(path.join(DIR,p));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);}
(async()=>{
  const inputs={
    tpl21:ab('二(1).115年○月醫療品質指標月報(TCPI.QIP).xlsx'),
    tpl22:fs.readFileSync(path.join(__dirname,'templates','摘要表_template.docx')),
    src1:ab('一(1).個別群組報表(綜合).xls'),src2:ab('一(2).個別群組報表(精神).xls'),
    src3:ab('一(3).月指標_臨床指標-115-○(月).xlsx'),
  };
  const out=await MonthlyReport.generate({ExcelJS,XLSX,PizZip,Docxtemplater},inputs);
  out.log.forEach(l=>console.log(' ',l));
  const sd=MonthlyReport._buildSummaryData(out.results);
  console.log('\n紅燈構面分組:');sd.redGroups.forEach(g=>console.log('  ['+g.cat+'] '+g.items.length+'項: '+g.items.map(i=>i.name.slice(0,10)).join(', ')));
  console.log('黃燈構面分組:');sd.yellowGroups.forEach(g=>console.log('  ['+g.cat+'] '+g.items.length+'項: '+g.items.map(i=>i.name.slice(0,10)).join(', ')));
  if(out.docxOut){fs.writeFileSync(path.join(__dirname,'out_二2.docx'),out.docxOut);console.log('\n已輸出 out_二2.docx');}
})();
