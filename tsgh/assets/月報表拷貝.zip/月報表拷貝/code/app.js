/* 網頁介面邏輯：讀取上傳來源檔 → 呼叫 core.js → 顯示結果與下載 */
(function () {
  'use strict';

  function b64ToArrayBuffer(b64) {
    var bin = atob(b64), len = bin.length, bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
    return bytes.buffer;
  }
  function fileToArrayBuffer(file) {
    return new Promise(function (res, rej) {
      if (!file) return res(null);
      var r = new FileReader();
      r.onload = function () { res(r.result); };
      r.onerror = rej;
      r.readAsArrayBuffer(file);
    });
  }
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }

  var generated = null;

  async function run() {
    var btn = $('genBtn'); btn.disabled = true; btn.textContent = '產生中…';
    $('result').style.display = 'none';
    try {
      var Docx = window.docxtemplater || window.Docxtemplater;
      var deps = { XLSX: window.XLSX, PizZip: window.PizZip, Docxtemplater: Docx };

      var inputs = {
        tpl21: b64ToArrayBuffer(window.EMBEDDED_TEMPLATES.tpl21_b64),
        tpl22: b64ToArrayBuffer(window.EMBEDDED_TEMPLATES.tpl22_b64),
        src1: await fileToArrayBuffer($('f1').files[0]),
        src2: await fileToArrayBuffer($('f2').files[0]),
        src3: await fileToArrayBuffer($('f3').files[0]),
        src4: await fileToArrayBuffer($('f4').files[0]),
        src5: await fileToArrayBuffer($('f5').files[0])
      };
      if (!inputs.src1 && !inputs.src2 && !inputs.src3) {
        alert('請至少上傳 一(1)、一(2) 或 一(3) 來源檔'); throw new Error('no source');
      }
      // docxtemplater 需要 nodebuffer/blob；瀏覽器用 PizZip 讀 tpl22 需 Uint8Array
      inputs.tpl22 = new Uint8Array(inputs.tpl22);

      var out = await window.MonthlyReport.generate(deps, inputs);
      generated = out;
      render(out);
    } catch (e) {
      console.error(e);
      if (e.message !== 'no source') alert('產生失敗：' + e.message);
    } finally {
      btn.disabled = false; btn.textContent = '產生月報';
    }
  }

  function render(out) {
    $('result').style.display = 'block';
    // log
    var logBox = $('log'); logBox.innerHTML = '';
    out.log.forEach(function (l) { logBox.appendChild(el('div', l.indexOf('⚠') >= 0 ? 'warn' : '', l)); });
    // counts
    $('redCount').textContent = out.results.red.length;
    $('yellowCount').textContent = out.results.yellow.length;
    $('nfCount').textContent = out.results.notFound.length;
    // table
    var tb = $('lightTable'); tb.innerHTML = '';
    var head = el('tr');
    ['燈號', '構面', '指標名稱', '數值', '閾值/目標值'].forEach(function (h) { head.appendChild(el('th', null, h)); });
    tb.appendChild(head);
    out.results.red.concat(out.results.yellow).forEach(function (r) {
      var tr = el('tr', r.light.indexOf('紅燈') === 0 ? 'red' : 'yellow');
      [r.light, r.cat, r.name, r.val, r.threshold].forEach(function (v) { tr.appendChild(el('td', null, v == null ? '' : String(v))); });
      tb.appendChild(tr);
    });
    // notFound
    $('nfList').textContent = out.results.notFound.length ? ('查無來源：' + out.results.notFound.join('、')) : '';
  }

  function download(which) {
    if (!generated) return;
    if (which === 'xlsx') {
      saveAs(generated.xlsxOut, '二(1).醫療品質指標月報(TCPI.QIP).xlsx');
    } else if (which === 'docx' && generated.docxOut) {
      saveAs(generated.docxOut, '二(2).醫療品質指標監測摘要表.docx');
    }
  }

  window.addEventListener('DOMContentLoaded', function () {
    $('genBtn').addEventListener('click', run);
    $('dlXlsx').addEventListener('click', function () { download('xlsx'); });
    $('dlDocx').addEventListener('click', function () { download('docx'); });
  });
})();
