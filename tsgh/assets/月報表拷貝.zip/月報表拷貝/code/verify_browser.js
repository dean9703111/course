/* 模擬瀏覽器環境：載入實際 shipped 的 lib/*.js（瀏覽器打包版）+ templates.js + core.js，
   跑完整 generate 流程，驗證雙擊 index.html 時的真實程式路徑。 */
const fs = require('fs'), path = require('path'), vm = require('vm');
const DIR = path.resolve(__dirname, '..');

// 建立假的瀏覽器全域環境（隱藏 module/exports 以觸發 UMD 的 window 分支）
const sandbox = {};
sandbox.window = sandbox;
sandbox.self = sandbox;
sandbox.global = sandbox;
sandbox.navigator = { userAgent: 'node' };
sandbox.atob = s => Buffer.from(s, 'base64').toString('binary');
sandbox.btoa = s => Buffer.from(s, 'binary').toString('base64');
sandbox.console = console;
sandbox.setTimeout = setTimeout; sandbox.clearTimeout = clearTimeout;
sandbox.setInterval = setInterval; sandbox.clearInterval = clearInterval;
sandbox.queueMicrotask = queueMicrotask; sandbox.Promise = Promise;
sandbox.setImmediate = setImmediate;
sandbox.TextEncoder = TextEncoder; sandbox.TextDecoder = TextDecoder;
sandbox.Uint8Array = Uint8Array; sandbox.ArrayBuffer = ArrayBuffer;
sandbox.Blob = require('buffer').Blob;
try { var xmldom = require(process.env.NM + '/@xmldom/xmldom');
  sandbox.DOMParser = xmldom.DOMParser; sandbox.XMLSerializer = xmldom.XMLSerializer; } catch (e) {}
vm.createContext(sandbox);

function load(rel) {
  const code = fs.readFileSync(path.join(__dirname, rel), 'utf8');
  vm.runInContext(code, sandbox, { filename: rel });
}
// 與 index.html 完全相同的載入清單（已不含 exceljs）
['lib/xlsx.full.min.js', 'lib/pizzip.js', 'lib/docxtemplater.js', 'templates.js', 'core.js'].forEach(load);

console.log('globals:', ['XLSX','PizZip','docxtemplater','MonthlyReport','EMBEDDED_TEMPLATES']
  .map(g => g + '=' + (sandbox[g] ? 'OK' : 'MISSING')).join('  '));

function ab(p){const b=fs.readFileSync(path.join(DIR,p));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);}
function b64ab(b64){const bin=sandbox.atob(b64);const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u.buffer;}

(async () => {
  const Docx = sandbox.docxtemplater || sandbox.Docxtemplater;
  const deps = { XLSX: sandbox.XLSX, PizZip: sandbox.PizZip, Docxtemplater: Docx };
  const inputs = {
    tpl21: b64ab(sandbox.EMBEDDED_TEMPLATES.tpl21_b64),
    tpl22: new Uint8Array(b64ab(sandbox.EMBEDDED_TEMPLATES.tpl22_b64)),
    src1: ab('一(1).個別群組報表(綜合).xls'),
    src2: ab('一(2).個別群組報表(精神).xls'),
    src3: ab('一(3).月指標_臨床指標-115-○(月).xlsx'),
    src4: ab('一(4).管制圖下載(綜合).xls'),
    src5: ab('一(5).管制圖下載(精神).xls'),
  };
  const out = await sandbox.MonthlyReport.generate(deps, inputs);
  console.log('\n--- 產生流程 LOG ---'); out.log.forEach(l => console.log(' ', l));
  console.log('紅燈', out.results.red.length, '黃燈', out.results.yellow.length, '查無來源', out.results.notFound.length);
  console.log('\n--- 紅/黃燈 SPC 備註 ---');
  out.results.red.concat(out.results.yellow).forEach(r =>
    console.log('  ' + (r.light.indexOf('紅') === 0 ? '紅' : '黃') + ' ' + r.code + ' ' + String(r.name).slice(0, 16) + ' → SPC=' + (r.spc || '(穩定)')));
  var OUT = process.env.OUTDIR || __dirname;
  var xbuf = Buffer.isBuffer(out.xlsxOut) ? out.xlsxOut : Buffer.from(await out.xlsxOut.arrayBuffer());
  fs.writeFileSync(path.join(OUT, 'out_browser_二1.xlsx'), xbuf);
  if (out.docxOut) {
    var buf = Buffer.isBuffer(out.docxOut) ? out.docxOut : Buffer.from(await out.docxOut.arrayBuffer());
    fs.writeFileSync(path.join(OUT, 'out_browser_二2.docx'), buf);
    console.log('docx 類型：', out.docxOut.constructor.name, '大小', buf.length, 'bytes');
  } else { console.log('⚠ docxOut 為空'); }
  console.log('✅ 已用 shipped 瀏覽器函式庫輸出 out_browser_二1.xlsx / out_browser_二2.docx');
})().catch(e => { console.log('❌ 失敗：', e.message); process.exit(1); });
