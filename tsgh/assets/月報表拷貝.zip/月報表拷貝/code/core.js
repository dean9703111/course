/* =====================================================================
 * 醫院月報表產生器 — 核心邏輯 (core.js) v2
 *
 * 【重要架構決策】
 *   二(1) Excel 不再用 ExcelJS 重寫整個檔案（會破壞 definedNames/rels 導致
 *   Excel 無法開啟），改為「外科手術式修補」：用 PizZip 打開原始範本 ZIP，
 *   僅以 DOMParser 修改需要變動的儲存格與樣式，其餘部件（calcChain、
 *   printerSettings、具名範圍、rels）完全保留原樣 → 保證 Excel 可開啟。
 *
 *   相依（由外部注入）：
 *     XLSX        — 讀取 .xls / .xlsx 來源檔（含管制圖）
 *     PizZip      — 讀寫 xlsx / docx 的 ZIP
 *     Docxtemplater — 產生 二(2).docx 摘要表
 *     （瀏覽器原生 DOMParser / XMLSerializer；Node 端由 verify 注入 xmldom）
 * ===================================================================== */
(function (root) {
  'use strict';

  var NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  var FILL_RED_ARGB = 'FFF2DCDB';
  var FILL_YELLOW_ARGB = 'FFFFFFCC';

  // ---- 數值解析 ----
  function num(v) {
    if (v === null || v === undefined) return NaN;
    if (typeof v === 'number') return v;
    var s = String(v).trim().replace(/,/g, '');
    if (s === '' || s === '---' || s === 'NR' || s === 'N/A' || s === 'NP' || s === 'NQ') return NaN;
    var n = parseFloat(s); return isNaN(n) ? NaN : n;
  }
  function numOrNull(v) { var n = num(v); return isNaN(n) ? null : n; }

  // ---- 燈號 / 備註 判斷（對應「超過閾值判斷公式.txt」）----
  function judgeTCPI(dir, val, redTh, yellowTh) {
    dir = String(dir || '').trim();
    if (dir === '參考指標' || dir === '') return '';
    var v = num(val), r = num(redTh), y = num(yellowTh);
    if (isNaN(v)) return '';
    if (dir === '負向') { if (!isNaN(r) && v > r) return '紅燈(超過閾值)'; if (!isNaN(y) && v > y) return '黃燈(超過目標值)'; return ''; }
    if (dir === '正向') { if (!isNaN(r) && v < r) return '紅燈(低於閾值)'; if (!isNaN(y) && v < y) return '黃燈(低於目標值)'; return ''; }
    return '';
  }
  function judgeQIP(dir, val, th) {
    dir = String(dir || '').trim();
    if (dir === '參考指標' || dir === '') return '';
    var v = num(val), t = num(th);
    if (isNaN(v) || isNaN(t)) return '';
    if (dir === '負向') return v > t ? '超過閾值' : '';
    if (dir === '正向') return v < t ? '低於閾值' : '';
    return '';
  }

  // ---- 來源檔 → map ----
  function mapFromGroupReport(XLSX, buf, log, label) {
    var m = {}; if (!buf) return m;
    try {
      var wb = XLSX.read(buf, { type: 'array' });
      var rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' });
      for (var i = 1; i < rows.length; i++) {
        var code = String(rows[i][0] || '').trim();
        if (!code || code.indexOf('<') === 0) continue;
        m[code] = { num: rows[i][5], den: rows[i][6], val: rows[i][7] };
      }
      log.push(label + '：讀入 ' + Object.keys(m).length + ' 筆指標');
    } catch (e) { log.push('⚠ ' + label + ' 讀取失敗：' + e.message); }
    return m;
  }
  function mapFromMonthlyIndicator(XLSX, buf, log) {
    var m = {}; if (!buf) return m;
    try {
      var wb = XLSX.read(buf, { type: 'array' });
      var name = wb.SheetNames.filter(function (n) { return n.indexOf('指標') >= 0; }).pop() || wb.SheetNames[0];
      var rows = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, defval: '' });
      for (var i = 2; i < rows.length; i++) {
        var code = String(rows[i][0] || '').trim();
        if (!code || code.indexOf('<') === 0) continue;
        m[code] = { num: rows[i][3], den: rows[i][4], val: rows[i][5] };
      }
      log.push('一(3) 月指標：讀入 ' + Object.keys(m).length + ' 筆 (' + name + ')');
    } catch (e) { log.push('⚠ 一(3) 讀取失敗：' + e.message); }
    return m;
  }

  // ---- SPC 管制圖 ----
  function spcNorm(s) {
    s = String(s == null ? '' : s).replace(/_\d+$/, '').replace(/\s+/g, '');
    s = s.replace(/（/g, '(').replace(/）/g, ')').replace(/≧/g, '≥').replace(/≦/g, '≤').replace(/病人/g, '');
    return s.trim();
  }
  function spcBase(s) { return spcNorm(s).replace(/\(.*?\)/g, ''); }
  function parseSPC(XLSX, buf, list, log, label) {
    if (!buf) return;
    try {
      var wb = XLSX.read(buf, { type: 'array' }), n = 0;
      wb.SheetNames.forEach(function (sn) {
        if (sn === '總表') return;
        var rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: '' });
        var hdr = -1;
        for (var i = 0; i < rows.length; i++) { if (String(rows[i][0]).trim() === 'Date') { hdr = i; break; } }
        if (hdr < 0) return;
        var last = null;
        for (var j = hdr + 1; j < rows.length; j++) { if (!/^\d{6}$/.test(String(rows[j][0]).trim())) break; last = rows[j]; }
        if (!last) return;
        var v = num(last[3]), ucl = num(last[4]), p2 = num(last[5]), m2 = num(last[9]), lcl = num(last[10]), sig = '';
        if (!isNaN(v)) {
          if ((!isNaN(ucl) && v > ucl) || (!isNaN(lcl) && v < lcl)) sig = '>3σ';
          else if ((!isNaN(p2) && v > p2) || (!isNaN(m2) && v < m2)) sig = '>2σ';
        }
        list.push({ name: sn, norm: spcNorm(sn), base: spcBase(sn), sig: sig }); n++;
      });
      log.push(label + '：解析 ' + n + ' 個管制圖分頁');
    } catch (e) { log.push('⚠ ' + label + ' SPC 解析失敗：' + e.message); }
  }
  function matchSPC(indName, list) {
    var q = spcNorm(indName), qb = spcBase(indName), i;
    for (i = 0; i < list.length; i++) if (list[i].norm === q) return list[i].sig;
    for (i = 0; i < list.length; i++) if (list[i].base && list[i].base === qb) return list[i].sig;
    for (i = 0; i < list.length; i++) { var b = list[i].base; if (b && qb && (b.indexOf(qb) >= 0 || qb.indexOf(b) >= 0) && Math.min(b.length, qb.length) >= 4) return list[i].sig; }
    var best = null, bs = 0, qset = {}; for (i = 0; i < qb.length; i++) qset[qb[i]] = 1;
    for (i = 0; i < list.length; i++) {
      var b2 = list[i].base; if (!b2) continue;
      var inter = 0, seen = {};
      for (var k = 0; k < b2.length; k++) if (qset[b2[k]] && !seen[b2[k]]) { inter++; seen[b2[k]] = 1; }
      var uni = Object.keys(qset).length + b2.length - inter, sc = uni ? inter / uni : 0;
      if (sc > bs) { bs = sc; best = list[i]; }
    }
    return (best && bs >= 0.75) ? best.sig : null;
  }

  // ====================== XLSX 手術式修補 ======================
  function getDomParser() {
    if (typeof DOMParser !== 'undefined') return new DOMParser();
    throw new Error('環境缺少 DOMParser');
  }
  function serialize(doc) {
    if (typeof XMLSerializer !== 'undefined') return new XMLSerializer().serializeToString(doc);
    throw new Error('環境缺少 XMLSerializer');
  }
  function parseSST(xml) {
    var doc = getDomParser().parseFromString(xml, 'application/xml');
    var sis = doc.getElementsByTagName('si'), arr = [];
    for (var i = 0; i < sis.length; i++) {
      var ts = sis[i].getElementsByTagName('t'), s = '';
      for (var j = 0; j < ts.length; j++) s += (ts[j].textContent || '');
      arr.push(s);
    }
    return arr;
  }
  function colOf(ref) { return ref.replace(/[0-9]/g, ''); }
  function rowNumOf(ref) { return parseInt(ref.replace(/[^0-9]/g, ''), 10); }

  // 建立 row->{ref->cellEl} 索引
  function indexSheet(doc) {
    var rows = doc.getElementsByTagName('row'), idx = {};
    for (var i = 0; i < rows.length; i++) {
      var rn = parseInt(rows[i].getAttribute('r'), 10);
      var cells = rows[i].getElementsByTagName('c'), cm = {};
      for (var j = 0; j < cells.length; j++) cm[colOf(cells[j].getAttribute('r'))] = cells[j];
      idx[rn] = { rowEl: rows[i], cells: cm };
    }
    return idx;
  }
  function cellText(cell, sst) {
    if (!cell) return '';
    var t = cell.getAttribute('t');
    if (t === 's') { var v = cell.getElementsByTagName('v')[0]; return v ? (sst[parseInt(v.textContent, 10)] || '') : ''; }
    if (t === 'inlineStr') { var is = cell.getElementsByTagName('t')[0]; return is ? is.textContent : ''; }
    var vv = cell.getElementsByTagName('v')[0]; return vv ? vv.textContent : '';
  }
  function setNumeric(doc, cell, value) {
    if (value === null || value === undefined || (typeof value === 'number' && isNaN(value))) return;
    cell.removeAttribute('t');
    while (cell.firstChild) cell.removeChild(cell.firstChild);
    var v = doc.createElementNS(NS, 'v'); v.appendChild(doc.createTextNode(String(value)));
    cell.appendChild(v);
  }
  function setInlineStr(doc, cell, text) {
    while (cell.firstChild) cell.removeChild(cell.firstChild);
    if (text === '' || text === null || text === undefined) { cell.removeAttribute('t'); return; }
    cell.setAttribute('t', 'inlineStr');
    var is = doc.createElementNS(NS, 'is'), t = doc.createElementNS(NS, 't');
    t.appendChild(doc.createTextNode(String(text))); is.appendChild(t); cell.appendChild(is);
  }

  // styles.xml：找/建 紅黃 fill 索引；提供 (origXf,color)->newXf clone 快取
  function StyleManager(stylesXml) {
    this.doc = getDomParser().parseFromString(stylesXml, 'application/xml');
    this.fills = this.doc.getElementsByTagName('fills')[0];
    this.cellXfs = this.doc.getElementsByTagName('cellXfs')[0];
    this.redFill = this._ensureFill(FILL_RED_ARGB);
    this.yellowFill = this._ensureFill(FILL_YELLOW_ARGB);
    this.cache = {};
  }
  StyleManager.prototype._ensureFill = function (argb) {
    // 尋找既有 rgb fill；否則新增
    var fs = this.fills.getElementsByTagName('fill');
    for (var i = 0; i < fs.length; i++) {
      var fg = fs[i].getElementsByTagName('fgColor')[0];
      if (fg && (fg.getAttribute('rgb') || '').toUpperCase() === argb) return i;
    }
    var fill = this.doc.createElementNS(NS, 'fill'), pf = this.doc.createElementNS(NS, 'patternFill');
    pf.setAttribute('patternType', 'solid');
    var fg2 = this.doc.createElementNS(NS, 'fgColor'); fg2.setAttribute('rgb', argb);
    var bg = this.doc.createElementNS(NS, 'bgColor'); bg.setAttribute('indexed', '64');
    pf.appendChild(fg2); pf.appendChild(bg); fill.appendChild(pf); this.fills.appendChild(fill);
    var n = this.fills.getElementsByTagName('fill').length;
    this.fills.setAttribute('count', String(n));
    return n - 1;
  };
  StyleManager.prototype.coloredXf = function (origS, color) {
    var fillId = color === 'red' ? this.redFill : this.yellowFill;
    var key = origS + ':' + fillId;
    if (this.cache[key] != null) return this.cache[key];
    var xfs = this.cellXfs.getElementsByTagName('xf');
    var base = xfs[parseInt(origS || '0', 10)] || xfs[0];
    var clone = base.cloneNode(true);
    clone.setAttribute('fillId', String(fillId));
    clone.setAttribute('applyFill', '1');
    this.cellXfs.appendChild(clone);
    var n = this.cellXfs.getElementsByTagName('xf').length;
    this.cellXfs.setAttribute('count', String(n));
    var idx = n - 1; this.cache[key] = idx; return idx;
  };
  StyleManager.prototype.xml = function () { return serialize(this.doc); };

  function colorRow(doc, sm, rowIdx, cols, color) {
    cols.forEach(function (c) {
      var cell = rowIdx.cells[c];
      if (cell) cell.setAttribute('s', String(sm.coloredXf(cell.getAttribute('s') || '0', color)));
    });
  }

  var COLS_TCPI = ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N'];
  var COLS_QIP = ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];

  function patchWorkbook(PizZip, XLSX, inputs, log) {
    var tcpiMap = Object.assign({},
      mapFromGroupReport(XLSX, inputs.src1, log, '一(1) 綜合'),
      mapFromGroupReport(XLSX, inputs.src2, log, '一(2) 精神'));
    var qipMap = mapFromMonthlyIndicator(XLSX, inputs.src3, log);
    var spcList = [];
    parseSPC(XLSX, inputs.src4, spcList, log, '一(4) 管制圖(綜合)');
    parseSPC(XLSX, inputs.src5, spcList, log, '一(5) 管制圖(精神)');

    var zip = new PizZip(inputs.tpl21);
    var sst = parseSST(zip.file('xl/sharedStrings.xml').asText());

    // 對應 工作表名稱 -> sheetN.xml 路徑
    var wbDoc = getDomParser().parseFromString(zip.file('xl/workbook.xml').asText(), 'application/xml');
    var relsDoc = getDomParser().parseFromString(zip.file('xl/_rels/workbook.xml.rels').asText(), 'application/xml');
    var relMap = {}; var rels = relsDoc.getElementsByTagName('Relationship');
    for (var i = 0; i < rels.length; i++) relMap[rels[i].getAttribute('Id')] = rels[i].getAttribute('Target');
    var sheetPath = {}; var shEls = wbDoc.getElementsByTagName('sheet');
    for (i = 0; i < shEls.length; i++) {
      var rid = shEls[i].getAttribute('r:id') || shEls[i].getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id');
      var tgt = relMap[rid]; if (tgt && tgt.indexOf('/') !== 0) tgt = 'xl/' + tgt;
      sheetPath[shEls[i].getAttribute('name')] = tgt;
    }

    var sm = new StyleManager(zip.file('xl/styles.xml').asText());
    var results = { red: [], yellow: [], notFound: [], updated: 0 };

    // ---- TCPI 兩表 ----
    ['TCPI_綜合照護', 'TCPI_急性精神'].forEach(function (sheetName) {
      var path = sheetPath[sheetName]; if (!path) { log.push('⚠ 找不到 ' + sheetName); return; }
      var doc = getDomParser().parseFromString(zip.file(path).asText(), 'application/xml');
      var idx = indexSheet(doc), cat = '';
      Object.keys(idx).map(Number).sort(function (a, b) { return a - b; }).forEach(function (r) {
        if (r < 5) return;
        var cells = idx[r].cells;
        var aTxt = cellText(cells['A'], sst).replace(/\s+/g, ' ').trim(); if (aTxt) cat = aTxt;
        var code = cellText(cells['B'], sst).trim(); if (!code) return;
        var dir = cellText(cells['F'], sst).trim();
        var src = tcpiMap[code];
        if (src) {
          setNumeric(doc, cells['H'], numOrNull(src.num));
          setNumeric(doc, cells['I'], numOrNull(src.den));
          setNumeric(doc, cells['J'], numOrNull(src.val));
          results.updated++;
        } else results.notFound.push(sheetName + ' / ' + code);

        var val = cellText(cells['J'], sst);
        var redTh = cellText(cells['L'], sst), yTh = cellText(cells['M'], sst);
        var light = judgeTCPI(dir, val, redTh, yTh);
        if (cells['N']) setInlineStr(doc, cells['N'], light);

        var indName = cellText(cells['C'], sst), spcSig = '';
        if (dir !== '參考指標' && spcList.length && cells['K']) {
          spcSig = matchSPC(indName, spcList) || '';
          setInlineStr(doc, cells['K'], spcSig || '穩定');
        }

        if (light) {
          var color = light.indexOf('紅燈') === 0 ? 'red' : 'yellow';
          colorRow(doc, sm, idx[r], COLS_TCPI, color);
          var rec = { sheet: sheetName, cat: cat, code: code, name: indName,
            unit: cellText(cells['E'], sst), dir: dir, uom: cellText(cells['G'], sst),
            num: num(cellText(cells['H'], sst)), den: num(cellText(cells['I'], sst)), val: num(val),
            threshold: numOrNull(color === 'red' ? redTh : yTh), light: light, spc: spcSig };
          (color === 'red' ? results.red : results.yellow).push(rec);
        }
      });
      zip.file(path, serialize(doc));
    });

    // ---- QIP：更新 F/G/H，保留 J 公式，紅燈上色 ----
    var qPath = sheetPath['QIP'];
    if (qPath) {
      var qdoc = getDomParser().parseFromString(zip.file(qPath).asText(), 'application/xml');
      var qidx = indexSheet(qdoc);
      Object.keys(qidx).map(Number).sort(function (a, b) { return a - b; }).forEach(function (r) {
        if (r < 4) return;
        var cells = qidx[r].cells;
        var code = cellText(cells['B'], sst).trim(); if (!code) return;
        var dir = cellText(cells['E'], sst).trim();
        var s2 = qipMap[code];
        if (s2) {
          setNumeric(qdoc, cells['F'], numOrNull(s2.num));
          setNumeric(qdoc, cells['G'], numOrNull(s2.den));
          setNumeric(qdoc, cells['H'], numOrNull(s2.val));
        } else results.notFound.push('QIP / ' + code);
        var note = judgeQIP(dir, cellText(cells['H'], sst), cellText(cells['I'], sst));
        if (note) colorRow(qdoc, sm, qidx[r], COLS_QIP, 'red');
      });
      zip.file(qPath, serialize(qdoc));
    }

    // styles 更新
    zip.file('xl/styles.xml', sm.xml());
    // 讓 Excel 開檔時重算 QIP 公式（安全屬性）
    try {
      var wbx = zip.file('xl/workbook.xml').asText();
      if (wbx.indexOf('<calcPr') >= 0 && wbx.indexOf('fullCalcOnLoad') < 0) {
        wbx = wbx.replace('<calcPr', '<calcPr fullCalcOnLoad="1"');
        zip.file('xl/workbook.xml', wbx);
      }
    } catch (e) {}

    log.push('二(1) 修補完成：更新 ' + results.updated + ' 筆，紅燈 ' + results.red.length + '、黃燈 ' + results.yellow.length + ' 項');
    var out = zip.generate({ type: (typeof window !== 'undefined' ? 'blob' : 'nodebuffer'), compression: 'DEFLATE',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    return { output: out, results: results };
  }

  // ====================== 二(2) 摘要表 (docx) ======================
  function groupByCat(list) {
    var order = [], byCat = {}, idx = 0;
    list.forEach(function (x) {
      var cat = x.cat || '未分類';
      if (!byCat[cat]) { byCat[cat] = { cat: cat, items: [] }; order.push(cat); }
      idx++;
      byCat[cat].items.push({
        idx: idx, name: String(x.name || ''), unit: String(x.unit || ''), dir: String(x.dir || ''),
        uom: String(x.uom || ''), num: x.num == null || isNaN(x.num) ? '' : x.num,
        den: x.den == null || isNaN(x.den) ? '' : x.den, val: x.val == null || isNaN(x.val) ? '' : x.val,
        threshold: x.threshold == null ? '' : x.threshold, note: x.spc || ''
      });
    });
    return order.map(function (c) { return byCat[c]; });
  }
  function buildSummaryData(results) {
    return { redGroups: groupByCat(results.red), yellowGroups: groupByCat(results.yellow) };
  }
  function buildReport22(PizZip, Docxtemplater, tpl22, results, log) {
    if (!tpl22) { log.push('（未提供 二(2) 模板，略過摘要表）'); return null; }
    try {
      var zip = new PizZip(tpl22);
      var doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true });
      doc.render(buildSummaryData(results));
      var out = doc.getZip().generate({ type: (typeof window !== 'undefined' ? 'blob' : 'nodebuffer'),
        compression: 'DEFLATE', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
      log.push('二(2) 摘要表產生完成：紅燈 ' + results.red.length + '、黃燈 ' + results.yellow.length + ' 項');
      return out;
    } catch (e) { log.push('⚠ 二(2) 產生失敗：' + e.message); return null; }
  }

  // ---- 對外主入口 ----
  async function generate(deps, inputs) {
    var log = [];
    var r21 = patchWorkbook(deps.PizZip, deps.XLSX, inputs, log);
    var r22 = deps.Docxtemplater ? buildReport22(deps.PizZip, deps.Docxtemplater, inputs.tpl22, r21.results, log) : null;
    return { xlsxOut: r21.output, docxOut: r22, results: r21.results, log: log };
  }

  root.MonthlyReport = {
    generate: generate, judgeTCPI: judgeTCPI, judgeQIP: judgeQIP,
    _buildSummaryData: buildSummaryData, FILL_RED: FILL_RED_ARGB, FILL_YELLOW: FILL_YELLOW_ARGB
  };
})(typeof window !== 'undefined' ? window : global);
