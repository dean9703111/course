"""護理師排班 MVP — Streamlit 網頁介面。

啟動：
    cd code
    pip install -r requirements.txt
    streamlit run app.py

流程：上傳上月班表(.xlsx) → 產生下月班表 → 檢視驗證報告與每日人力 → 下載
輸出檔沿用上傳檔為範本，格式與 COUNTIF/驗證公式完整保留。
"""
from __future__ import annotations
import io
import os
import tempfile

import pandas as pd
import streamlit as st

from scheduler.reader import load_template
from scheduler.rules import RuleConfig, SHIFTS
from scheduler.engine import solve
from scheduler.writer import write_schedule, label_offs, formulas_preserved
from scheduler.validator import validate, summarize_daily

st.set_page_config(page_title="護理師排班產生器", layout="wide")
st.title("🗓️ 護理師排班產生器 (MVP)")
st.caption("上傳上月班表，自動產生下月班表；格式與公式與原檔一致。")

with st.sidebar:
    st.header("排班規則")
    st.caption("預設值來自現行規則，可即時調整。")
    minD = st.number_input("D 白班 最低人力", 1, 60, 16)
    minE = st.number_input("E 小夜 最低人力", 1, 60, 16)
    minN = st.number_input("N 大夜 最低人力", 1, 60, 14)
    max_consec = st.number_input("連續上班上限(天)", 1, 14, 5)
    max_n = st.number_input("連續大夜上限(天)", 1, 14, 4)
    leaders = st.number_input("每班小組長(A階)下限", 0, 10, 2)
    solve_time = st.slider("求解時間上限(秒)", 10, 180, 40)
    st.divider()
    st.caption("階層累進上限與休假視窗等進階規則見 scheduler/rules.py")


def build_rules() -> RuleConfig:
    r = RuleConfig()
    r.min_manpower = {"D": int(minD), "E": int(minE), "N": int(minN)}
    r.max_consecutive_work = int(max_consec)
    r.max_consecutive_N = int(max_n)
    r.min_leader_per_shift = int(leaders)
    return r


uploaded = st.file_uploader("上傳上月班表 (.xlsx)", type=["xlsx"])

if uploaded is not None:
    tmpdir = tempfile.mkdtemp()
    src = os.path.join(tmpdir, uploaded.name)
    with open(src, "wb") as f:
        f.write(uploaded.getbuffer())

    try:
        t = load_template(src)
    except Exception as e:
        st.error(f"無法解析班表結構：{e}")
        st.stop()

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("排班天數(自動)", t.n_days)
    c2.metric("人員數", len(t.people))
    c3.metric("納入排班", len(t.active_people))
    c4.metric("原檔公式數", formulas_preserved(src, t.sheet_name))

    if st.button("🚀 產生下月班表", type="primary"):
        rules = build_rules()
        with st.spinner(f"排班求解中（最多 {solve_time} 秒）…"):
            try:
                assignment = solve(t, rules, time_limit_s=int(solve_time))
            except RuntimeError as e:
                st.error(str(e))
                st.stop()
        meta = assignment.pop("_meta", {})

        passed, errs = validate(t, assignment, rules)
        if passed:
            st.success(f"✅ 排班完成且通過所有硬規則驗證（{meta.get('status')}，{meta.get('wall_time',0):.1f}s）")
        else:
            st.warning(f"⚠️ 已產生班表，但有 {len(errs)} 項規則未滿足（可延長求解時間或放寬規則）")
            with st.expander("違規明細"):
                for e in errs[:50]:
                    st.write("-", e)

        # 每日人力摘要
        st.subheader("每日人力摘要")
        df = pd.DataFrame(summarize_daily(t, assignment))
        df.columns = ["日", "D 白", "E 小夜", "N 大夜", "休假"]
        st.dataframe(df, use_container_width=True, height=280)

        # 寫回範本並提供下載
        out_path = os.path.join(tmpdir, "下月班表.xlsx")
        write_schedule(t, assignment, out_path, rules)
        out_formulas = formulas_preserved(out_path, t.sheet_name)
        st.caption(f"輸出檔保留公式數：{out_formulas}（與原檔一致代表統計/驗證公式完整）")

        with open(out_path, "rb") as f:
            st.download_button(
                "⬇️ 下載下月班表 (.xlsx)",
                data=f.read(),
                file_name="下月班表.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
else:
    st.info("請先上傳一份現行格式的 .xlsx 班表。系統會自動偵測日期天數與人員階層。")
