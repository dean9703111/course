#!/usr/bin/env bash
# 把 UI + ExcelJS + 排班邏輯 打包成單一自足 HTML（雙擊即用、離線）。
# 需求：本機或 node_modules 有 exceljs（npm install exceljs）。
set -e
cd "$(dirname "$0")"

EXCELJS="${EXCELJS_PATH:-node_modules/exceljs/dist/exceljs.min.js}"
if [ ! -f "$EXCELJS" ]; then
  EXCELJS="../node_modules/exceljs/dist/exceljs.min.js"
fi
if [ ! -f "$EXCELJS" ]; then
  echo "找不到 exceljs.min.js，請先 npm install exceljs，或設 EXCELJS_PATH。" >&2
  exit 1
fi

OUT="護理師排班產生器.html"
{
  cat _part_top.html
  echo '<script>'; cat "$EXCELJS"; echo '</script>'
  echo '<script>'; cat scheduler.js; echo '</script>'
  echo '<script>'; cat _app.js; echo '</script>'
  echo '</body></html>'
} > "$OUT"
echo "已產生 $OUT ($(wc -c < "$OUT") bytes)"
