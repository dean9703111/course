"""端到端自我驗證：讀真實班表 -> 產生下月 -> 寫回範本 -> 重新開檔 -> 驗證。

執行：python -m tests.self_verify  (於 code/ 目錄下)
全部通過會印出 ✅ 並 exit 0；任何一項失敗 exit 1。
"""
from __future__ import annotations
import os
import sys

from scheduler.reader import load_template
from scheduler.rules import RuleConfig
from scheduler.engine import solve
from scheduler.writer import write_schedule, formulas_preserved
from scheduler.validator import validate, summarize_daily

HERE = os.path.dirname(__file__)
SRC = os.path.abspath(os.path.join(HERE, "..", "..", "ER班表檔案(修)_V2.xlsx"))
OUT = os.path.abspath(os.path.join(HERE, "..", "output_next_month.xlsx"))


def main() -> int:
    rules = RuleConfig()
    checks = []

    # --- 1. 讀取與結構偵測 ---
    t = load_template(SRC)
    checks.append(("自動偵測排班天數", t.n_days > 0, f"n_days={t.n_days}"))
    checks.append(("偵測人員數", len(t.active_people) > 0, f"active={len(t.active_people)}"))

    # 範本原有公式數量（作為保留基準）
    base_formulas = formulas_preserved(SRC, t.sheet_name)

    # --- 2. 求解 ---
    solve_time = int(os.environ.get("SOLVE_TIME", "25"))
    assignment = solve(t, rules, time_limit_s=solve_time)
    meta = assignment.get("_meta", {})
    assignment = {k: v for k, v in assignment.items() if k != "_meta"}
    checks.append(("引擎求得可行解", True, f"status={meta.get('status')}, {meta.get('wall_time',0):.1f}s"))

    # --- 3. 驗證排班內容 ---
    passed, errs = validate(t, assignment, rules)
    checks.append(("排班符合所有硬規則", passed, "無違規" if passed else f"{len(errs)} 項違規"))

    # --- 4. 寫回範本並檢查格式/公式保留 ---
    write_schedule(t, assignment, OUT, rules)
    out_formulas = formulas_preserved(OUT, t.sheet_name)
    checks.append(("輸出檔公式完整保留", out_formulas >= base_formulas,
                   f"範本 {base_formulas} -> 輸出 {out_formulas}"))

    # --- 5. 輸出檔天數 / 結構一致 ---
    t2 = load_template(OUT)
    checks.append(("輸出檔天數與範本一致", t2.n_days == t.n_days, f"{t.n_days} == {t2.n_days}"))
    checks.append(("輸出檔可被重新解析", len(t2.people) == len(t.people),
                   f"{len(t2.people)} 位人員"))

    # --- 6. 寫入/讀出一致性：輸出檔的班別型態需與求解結果完全相同 ---
    from scheduler.reader import classify_cell
    import openpyxl
    wb = openpyxl.load_workbook(OUT, data_only=False)
    ws = wb[t2.sheet_name]
    row_by_label = {p.label: p.row for p in t2.people}
    mismatches = 0
    for label, seq in assignment.items():
        row = row_by_label[label]
        readback = [classify_cell(ws.cell(row, c).value) for c in t2.date_cols]
        if readback != seq:
            mismatches += 1
    checks.append(("寫入/讀出班別一致", mismatches == 0,
                   "完全一致" if mismatches == 0 else f"{mismatches} 位不一致"))

    # --- 報告 ---
    print("=" * 60)
    print("排班 MVP 自我驗證報告")
    print("=" * 60)
    all_ok = True
    for name, ok, detail in checks:
        mark = "✅" if ok else "❌"
        print(f"{mark}  {name:<20} {detail}")
        all_ok = all_ok and ok

    # 每日人力摘要（前 7 天）
    print("-" * 60)
    print("每日人力摘要（前 7 天） day: D/E/N/off")
    for row in summarize_daily(t, assignment)[:7]:
        print(f"  第{row['day']:>2}天  D={row['D']:>2} E={row['E']:>2} N={row['N']:>2} 休={row['off']:>2}")

    if not passed:
        print("-" * 60)
        print("違規明細（前 15 條）：")
        for e in errs[:15]:
            print("  -", e)

    print("=" * 60)
    print("結果：", "✅ 全部通過" if all_ok else "❌ 有項目未通過")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
