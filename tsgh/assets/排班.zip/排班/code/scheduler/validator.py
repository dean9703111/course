"""獨立驗證器：檢查排班結果是否符合所有硬規則。

刻意「不依賴引擎」重新實作檢查邏輯，才能真正抓出引擎的錯誤。
回傳 (passed: bool, report: List[str])。
"""
from __future__ import annotations
from typing import Dict, List, Optional, Tuple

from .rules import RuleConfig, SHIFTS, GROUPS
from .reader import Template

_TIER_START_GROUP = ["B", "C", "D", "E"]


def _groups_from(start: str) -> List[str]:
    return GROUPS[GROUPS.index(start):]


def validate(
    template: Template,
    assignment: Dict[str, List[Optional[str]]],
    rules: Optional[RuleConfig] = None,
) -> Tuple[bool, List[str]]:
    rules = rules or RuleConfig()
    people = template.active_people
    D = template.n_days
    errors: List[str] = []
    label_group = {p.label: p.group for p in people}
    tail = {p.label: p.tail for p in people}

    def shifts_on(day: int, labels=None):
        labels = labels or [p.label for p in people]
        cnt = {s: 0 for s in SHIFTS}
        for l in labels:
            c = assignment[l][day]
            if c in SHIFTS:
                cnt[c] += 1
        return cnt

    # 1) 每日最低人力
    for d in range(D):
        cnt = shifts_on(d)
        for s in SHIFTS:
            if cnt[s] < rules.min_manpower[s]:
                errors.append(f"[最低人力] 第{d+1}天 {s}班 僅 {cnt[s]} 人 (<{rules.min_manpower[s]})")

    # 2) 小組長 A 階 >= 2
    a_labels = [p.label for p in people if p.group == "A"]
    for d in range(D):
        cnt = shifts_on(d, a_labels)
        for s in SHIFTS:
            if cnt[s] < rules.min_leader_per_shift:
                errors.append(f"[小組長] 第{d+1}天 {s}班 A階僅 {cnt[s]} 人 (<{rules.min_leader_per_shift})")

    # 3) 階層累進上限
    for d in range(D):
        for s in SHIFTS:
            for cap, start in zip(rules.tier_caps[s], _TIER_START_GROUP):
                labels = [l for l in assignment if l in label_group and label_group[l] in _groups_from(start)]
                c = shifts_on(d, labels)[s]
                if c > cap:
                    errors.append(f"[階層上限] 第{d+1}天 {s}班 {start}階以下 {c} 人 (>{cap})")

    # 個人層級
    for p in people:
        lab = p.label
        seq = assignment[lab]
        h = tail[lab]

        # 4) 換班休息：N/E 隔天不可 D（含跨月）
        prev_last = h[-1] if h else None
        if prev_last in rules.forbid_next_day_D_after and seq[0] == "D":
            errors.append(f"[換班休息] {lab} 上月末({prev_last})後首日排D")
        for d in range(1, D):
            if seq[d] == "D" and seq[d-1] in rules.forbid_next_day_D_after:
                errors.append(f"[換班休息] {lab} 第{d+1}天D 前一天為{seq[d-1]}")

        # 5) 連續上班上限（含跨月歷史）
        # 只回報「由本月造成」的違規：超標當下那天必須落在本月(index >= base)，
        # 純上月歷史造成的既有連續紀錄不歸本月負責。
        base = len(h)
        hist = [1 if c in SHIFTS else 0 for c in h]
        wseq = hist + [1 if c in SHIFTS else 0 for c in seq]
        run = 0
        for i, v in enumerate(wseq):
            run = run + 1 if v else 0
            if run > rules.max_consecutive_work and i >= base:
                errors.append(f"[連續上班] {lab} 連續上班超過 {rules.max_consecutive_work} 天")
                break

        # 6) 連續大夜上限
        hist_n = [1 if c == "N" else 0 for c in h]
        nseq = hist_n + [1 if c == "N" else 0 for c in seq]
        run = 0
        for i, v in enumerate(nseq):
            run = run + 1 if v else 0
            if run > rules.max_consecutive_N and i >= base:
                errors.append(f"[連續大夜] {lab} 連續大夜超過 {rules.max_consecutive_N} 天")
                break

        # 7) 休假視窗
        off = [0 if c in SHIFTS else 1 for c in seq]
        for window, min_off in rules.rest_windows:
            if window <= D:
                for start in range(0, D - window + 1):
                    if sum(off[start:start+window]) < min_off:
                        errors.append(f"[休假] {lab} 第{start+1}~{start+window}天 休假 <{min_off} 日")
                        break

    passed = len(errors) == 0
    return passed, errors


def summarize_daily(template: Template, assignment: Dict[str, List[Optional[str]]]) -> List[Dict]:
    """每日人力摘要，供 UI 顯示。"""
    people = template.active_people
    rows = []
    for d in range(template.n_days):
        cnt = {s: 0 for s in SHIFTS}
        off = 0
        for p in people:
            c = assignment[p.label][d]
            if c in SHIFTS:
                cnt[c] += 1
            else:
                off += 1
        rows.append({"day": d + 1, **cnt, "off": off})
    return rows
