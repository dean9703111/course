"""排班引擎：用 OR-Tools CP-SAT 求解下月班表。

輸出：assignment[person_label][day_index] = 'D'/'E'/'N' 或 None(休假)
硬約束全部在此，若無解會拋出例外（表示規則彼此衝突，需鬆綁參數）。
"""
from __future__ import annotations
from typing import Dict, List, Optional

from ortools.sat.python import cp_model

from .rules import RuleConfig, SHIFTS, GROUPS
from .reader import Template


# 階層累進的「起始群組」：tier_caps 的四個上限分別對應
#   [B以下, C以下, D以下, E階]
_TIER_START_GROUP = ["B", "C", "D", "E"]


def _groups_from(start: str) -> List[str]:
    """回傳 start(含) 到最資淺 E 的群組清單。"""
    i = GROUPS.index(start)
    return GROUPS[i:]


def solve(
    template: Template,
    rules: Optional[RuleConfig] = None,
    fixed: Optional[Dict[str, Dict[int, Optional[str]]]] = None,
    time_limit_s: int = 60,
    seed: int = 0,
) -> Dict[str, List[Optional[str]]]:
    rules = rules or RuleConfig()
    fixed = fixed or {}
    people = template.active_people
    D = template.n_days
    m = cp_model.CpModel()

    # x[label][d][s] = 1 表示該人第 d 天上 s 班
    x: Dict[str, List[Dict[str, cp_model.IntVar]]] = {}
    work: Dict[str, List[cp_model.IntVar]] = {}
    for p in people:
        x[p.label] = []
        work[p.label] = []
        for d in range(D):
            row = {s: m.NewBoolVar(f"x_{p.label}_{d}_{s}") for s in SHIFTS}
            x[p.label].append(row)
            w = m.NewBoolVar(f"w_{p.label}_{d}")
            # 每天最多一個班；work = 是否上班
            m.Add(sum(row.values()) == w)
            work[p.label].append(w)

    # 預先固定的班別（預假 / 包班 / 指定），fixed[label][day] = 'D'/'E'/'N'/None
    for label, days in fixed.items():
        if label not in x:
            continue
        for d, code in days.items():
            if d < 0 or d >= D:
                continue
            if code in SHIFTS:
                m.Add(x[label][d][code] == 1)
            else:  # None => 當天休假
                m.Add(work[label][d] == 0)

    label_to_group = {p.label: p.group for p in people}
    labels_by_group = {g: [p.label for p in people if p.group == g] for g in GROUPS}

    # --- 每日約束 ---
    for d in range(D):
        # 1) 每班最低人力
        for s in SHIFTS:
            m.Add(sum(x[l][d][s] for l in x) >= rules.min_manpower[s])

        # 2) 小組長（A 階層）每班 >= 2
        for s in SHIFTS:
            apeople = labels_by_group["A"]
            if apeople:
                m.Add(sum(x[l][d][s] for l in apeople) >= rules.min_leader_per_shift)

        # 3) 階層累進上限
        for s in SHIFTS:
            caps = rules.tier_caps[s]
            for cap, start in zip(caps, _TIER_START_GROUP):
                grp_labels = [
                    l for l in x if label_to_group[l] in _groups_from(start)
                ]
                m.Add(sum(x[l][d][s] for l in grp_labels) <= cap)

    # --- 個人時序約束 ---
    for p in people:
        lab = p.label
        # 上月月底 tail（最舊->最新），用來銜接跨月連續性
        tail = p.tail  # e.g. [None,'E','E',...]

        # 4) 換班休息：前一天上 N 或 E，隔天不可上 D
        # 4a) 月內
        for d in range(1, D):
            for prev in rules.forbid_next_day_D_after:
                m.Add(x[lab][d]["D"] + x[lab][d - 1][prev] <= 1)
        # 4b) 跨月：上月最後一天若為 N/E，本月第一天不可 D
        if tail and tail[-1] in rules.forbid_next_day_D_after:
            m.Add(x[lab][0]["D"] == 0)

        # 5) 連續上班天數上限（含跨月）：任何 (max+1) 天視窗內上班 <= max
        wlen = rules.max_consecutive_work + 1
        # 建立含歷史的 work 序列（歷史為常數 0/1）
        hist = [1 if c in SHIFTS else 0 for c in tail]
        seq = hist + work[lab]           # 長度 = len(tail)+D
        base = len(hist)
        for start in range(0, len(seq) - wlen + 1):
            # 只約束「含至少一個決策變數」的視窗；純歷史視窗是常數，跳過
            if start + wlen <= base:
                continue
            m.Add(sum(seq[start:start + wlen]) <= rules.max_consecutive_work)

        # 6) 大夜連續上限：任何 (maxN+1) 天視窗內 N <= maxN（含跨月）
        nlen = rules.max_consecutive_N + 1
        hist_n = [1 if c == "N" else 0 for c in tail]
        nseq = hist_n + [x[lab][d]["N"] for d in range(D)]
        for start in range(0, len(nseq) - nlen + 1):
            if start + nlen <= base:
                continue
            m.Add(sum(nseq[start:start + nlen]) <= rules.max_consecutive_N)

        # 7) 休假視窗：任意 window 天內休假 >= min_off（僅在月內視窗）
        off = [1 - work[lab][d] for d in range(D)]
        for window, min_off in rules.rest_windows:
            if window <= D:
                for start in range(0, D - window + 1):
                    m.Add(sum(off[start:start + window]) >= min_off)
            else:
                # 視窗大於總天數時，換算為整體比例下限
                need = max(min_off * D // window, 0)
                m.Add(sum(off) >= need)

    # --- 目標：鼓勵「純班」(減少換班) + 工作量平衡 ---
    switch_terms = []
    for p in people:
        lab = p.label
        for d in range(1, D):
            for s in SHIFTS:
                # 若某天上 s、隔天不同班別，計一次「班別變動」的近似懲罰
                pass
        # 用「每人上到的班別種類數」近似純班：penalize using each shift type
        for s in SHIFTS:
            used = m.NewBoolVar(f"used_{lab}_{s}")
            m.AddMaxEquality(used, [x[lab][d][s] for d in range(D)])
            switch_terms.append(used)

    # 工作量平衡：讓各人上班總天數盡量接近
    totals = []
    for p in people:
        t = m.NewIntVar(0, D, f"tot_{p.label}")
        m.Add(t == sum(work[p.label]))
        totals.append(t)
    tmax = m.NewIntVar(0, D, "tmax")
    tmin = m.NewIntVar(0, D, "tmin")
    m.AddMaxEquality(tmax, totals)
    m.AddMinEquality(tmin, totals)

    # 綜合目標（權重：先平衡工作量，再鼓勵純班）
    m.Minimize(10 * (tmax - tmin) + sum(switch_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit_s
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = seed
    status = solver.Solve(m)

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        raise RuntimeError(
            f"排班無解（status={solver.StatusName(status)}）。"
            "可能規則彼此衝突或人力不足，請調整 rules.py 參數。"
        )

    # 取出結果
    result: Dict[str, List[Optional[str]]] = {}
    for p in people:
        seq: List[Optional[str]] = []
        for d in range(D):
            code = None
            for s in SHIFTS:
                if solver.Value(x[p.label][d][s]) == 1:
                    code = s
                    break
            seq.append(code)
        result[p.label] = seq

    result["_meta"] = {  # type: ignore
        "status": solver.StatusName(status),
        "objective": solver.ObjectiveValue(),
        "wall_time": solver.WallTime(),
    }
    return result
