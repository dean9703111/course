"""把排班結果寫回上傳的範本 —— 只覆寫資料格，保留所有公式與格式。

關鍵設計：以「上傳檔」為範本開啟，僅改動人員×日期的資料區，
其餘（COUNTIF 統計列、驗證列、樣式、合併儲存格）完全不碰，
因此 Excel 打開時公式會自動重算。
"""
from __future__ import annotations
from typing import Dict, List, Optional

import openpyxl

from .rules import RuleConfig, SHIFTS
from .reader import Template


def label_offs(seq: List[Optional[str]], rules: RuleConfig) -> List[str]:
    """把 D/E/N/None 序列轉為顯示碼：休假依規則標為『例』或『息』。

    每 statutory_period(預設7) 天內第一個休假日標為『例假』，其餘休假標『息』。
    """
    out: List[str] = []
    period = rules.statutory_period
    n = len(seq)
    statutory_taken = {}  # block_index -> 已指定例假
    for d in range(n):
        code = seq[d]
        if code in SHIFTS:
            out.append(code)
            continue
        block = d // period
        if not statutory_taken.get(block):
            out.append(rules.off_label_statutory)  # 例
            statutory_taken[block] = True
        else:
            out.append(rules.off_label_rest)       # 息
    return out


def write_schedule(
    template: Template,
    assignment: Dict[str, List[Optional[str]]],
    out_path: str,
    rules: Optional[RuleConfig] = None,
    clear_inactive: bool = True,
) -> str:
    rules = rules or RuleConfig()
    wb = openpyxl.load_workbook(template.path, data_only=False)
    ws = wb[template.sheet_name]

    date_cols = template.date_cols
    for p in template.people:
        if p.label in assignment:
            display = label_offs(assignment[p.label], rules)
            for i, c in enumerate(date_cols):
                ws.cell(p.row, c).value = display[i]
        elif clear_inactive and not p.active:
            for c in date_cols:
                ws.cell(p.row, c).value = None

    wb.save(out_path)
    return out_path


def formulas_preserved(out_path: str, sheet_name: str) -> int:
    """回傳輸出檔中仍為公式(以 '=' 開頭)的儲存格數量，供自我驗證。"""
    wb = openpyxl.load_workbook(out_path, data_only=False)
    ws = wb[sheet_name]
    count = 0
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith("="):
                count += 1
    return count
