"""排班規則設定（可彈性調整）。

預設值取自《案例_醫事人員排班_V2.docx》。所有數字都集中在這裡，
未來要調整規則，只需改這個檔案，不需動到演算法。
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List

# 班別代碼
SHIFTS = ["D", "E", "N"]          # 白班 / 小夜 / 大夜
GROUPS = ["A", "B", "C", "D", "E"]  # 資深(A) -> 資淺(E) 五個階層


@dataclass
class RuleConfig:
    # 每班每日最低人力
    min_manpower: Dict[str, int] = field(
        default_factory=lambda: {"D": 16, "E": 16, "N": 14}
    )

    # 連續上班天數上限
    max_consecutive_work: int = 5          # 任何班別連續上班最多 5 天
    max_consecutive_N: int = 4             # 大夜連續最多 4 天

    # 小組長（A 階層）每班每日最低人數
    min_leader_per_shift: int = 2

    # 階層累進上限：key 為班別，value 為 [B以下, C以下, D以下, E階] 的同時在班人數上限
    # 例：D 班 B 階(含)以下最多 14 人、C 階以下最多 11、D 階以下最多 8、E 階最多 4
    tier_caps: Dict[str, List[int]] = field(
        default_factory=lambda: {
            "D": [14, 11, 8, 4],
            "E": [14, 11, 8, 4],
            "N": [12, 9, 6, 3],
        }
    )

    # 換班休息：大夜(N)之後不可接白班(D)；小夜(E)之後不可接白班(D)（需連續 11 小時休息）
    forbid_next_day_D_after = ("N", "E")

    # 休假規則（滑動視窗）：於任意連續 window 天內，休假天數至少 min_off 天
    # 對應 docx：2 週內至少 2 日例假；4 週內至少 8 日例假及休息日
    rest_windows: List[tuple] = field(
        default_factory=lambda: [(14, 2), (28, 8)]
    )

    # 每 statutory_period 天至少安排 1 日「例假」（其餘休假標為「息」）
    statutory_period: int = 7

    # 工時（僅作為驗證參考；MVP 以「班別=1 個標準工時單位」計）
    max_daily_hours: int = 10
    max_4week_hours: int = 160

    # 產出時休假標記
    off_label_statutory: str = "例"   # 例假
    off_label_rest: str = "息"        # 休息日
