"""讀取上月班表，自動偵測表格結構（不寫死列數 / 天數）。

彈性重點：
  * 日期列、星期列、人員列、資料欄範圍，全部靠內容特徵自動偵測。
  * 排班天數 = 偵測到的日期欄數量（自動）。
  * 讀出每位人員上月「月底」的班別，供跨月連續性判斷。
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Dict, List, Optional

import openpyxl
from openpyxl.utils import get_column_letter

from .rules import SHIFTS

PERSON_RE = re.compile(r"^[A-Ea-e]\d+$")     # A1, B12, C3 ...
_SHIFT_PREFIX = ("D", "E", "N", "d", "e", "n")


def classify_cell(value) -> Optional[str]:
    """把儲存格內容歸類為工作班別(D/E/N) 或 None(休假/其他)。

    支援複合標記：'D/特'、'N/息'、'病E'、'生理N'、'新N' 等 —— 只要含 D/E/N 就視為該班。
    """
    if value is None:
        return None
    s = str(value).strip()
    if not s or s.startswith("="):
        return None
    # 純休假 / 假別代碼
    if s in ("例", "息", "國", "特", "補", "公", "離職"):
        return None
    # 依出現的班別字母判斷（處理 '生理E'、'D/特'、'新N' …）
    up = s.upper()
    for sh in SHIFTS:
        if sh in up:
            return sh
    return None


@dataclass
class Person:
    row: int          # 在 Excel 的列號
    label: str        # A1 / B2 ...
    group: str        # A~E 階層
    active: bool      # 是否納入排班（離職者為 False）
    tail: List[Optional[str]]  # 上月月底往前的班別序列（最舊 -> 最新）


@dataclass
class Template:
    path: str
    sheet_name: str
    date_row: int
    weekday_row: int
    first_col: int
    n_days: int
    people: List[Person]

    @property
    def date_cols(self) -> List[int]:
        return [self.first_col + i for i in range(self.n_days)]

    @property
    def weekdays(self) -> List[str]:
        wb = openpyxl.load_workbook(self.path, data_only=True)
        ws = wb[self.sheet_name]
        return [ws.cell(self.weekday_row, c).value for c in self.date_cols]

    @property
    def active_people(self) -> List[Person]:
        return [p for p in self.people if p.active]

    def group_rows(self) -> Dict[str, List[int]]:
        d: Dict[str, List[int]] = {}
        for p in self.people:
            d.setdefault(p.group, []).append(p.row)
        return d


def load_template(path: str, tail_len: int = 6) -> Template:
    wb = openpyxl.load_workbook(path, data_only=False)
    ws = wb.active

    # 1) 找日期列：col C 內容為 '日期'
    date_row = None
    for r in range(1, 12):
        if str(ws.cell(r, 3).value).strip() == "日期":
            date_row = r
            break
    if date_row is None:
        raise ValueError("找不到『日期』列，無法辨識表格結構。")
    weekday_row = date_row + 1

    # 2) 找日期欄：日期列中值為整數的欄，取連續區段
    date_cols = [
        c for c in range(1, ws.max_column + 1)
        if isinstance(ws.cell(date_row, c).value, (int, float))
    ]
    if not date_cols:
        raise ValueError("日期列沒有偵測到任何日期數字。")
    first_col = date_cols[0]
    # 取從 first_col 起的連續欄
    n_days = 1
    while first_col + n_days in date_cols:
        n_days += 1

    # 3) 找人員列：col B 為整數(組內序號) 且 col C 形如 A1/B2 …
    people: List[Person] = []
    for r in range(date_row + 1, ws.max_row + 1):
        b = ws.cell(r, 2).value
        c = ws.cell(r, 3).value
        if isinstance(b, (int, float)) and isinstance(c, str) and PERSON_RE.match(c.strip()):
            label = c.strip().upper()
            group = label[0]
            # 讀月底 tail
            tail = [
                classify_cell(ws.cell(r, first_col + n_days - 1 - k).value)
                for k in reversed(range(tail_len))
            ]
            # 是否離職 / 停排：整列出現 '離職'
            row_vals = [str(ws.cell(r, first_col + i).value) for i in range(n_days)]
            active = not any("離職" in v for v in row_vals)
            people.append(Person(r, label, group, active, tail))

    if not people:
        raise ValueError("找不到任何人員列。")

    return Template(
        path=path,
        sheet_name=ws.title,
        date_row=date_row,
        weekday_row=weekday_row,
        first_col=first_col,
        n_days=n_days,
        people=people,
    )


def col_letter(idx: int) -> str:
    return get_column_letter(idx)
