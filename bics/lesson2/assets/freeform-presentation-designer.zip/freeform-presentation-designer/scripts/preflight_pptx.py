#!/usr/bin/env python3
"""Run structural, geometric, text-fit, and render-gate checks on a PPTX."""

from __future__ import annotations

import argparse
import posixpath
import re
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from xml.etree import ElementTree as ET

from text_fit import evaluate_font_size


NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
EMU_PER_INCH = 914400.0
DEFAULT_SLIDE_WIDTH = 13.333
DEFAULT_SLIDE_HEIGHT = 7.5

DRAFT_MARKERS = (
    "待補",
    "請替換",
    "圖片放這裡",
    "主視覺圖片",
    "內容圖片",
    "[公司名稱]",
    "click to add",
    "lorem ipsum",
    "[insert",
    "todo",
)


@dataclass(frozen=True)
class Box:
    x: float
    y: float
    width: float
    height: float

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def bottom(self) -> float:
        return self.y + self.height

    @property
    def area(self) -> float:
        return max(self.width, 0.0) * max(self.height, 0.0)

    def intersection(self, other: "Box") -> float:
        width = max(0.0, min(self.right, other.right) - max(self.x, other.x))
        height = max(0.0, min(self.bottom, other.bottom) - max(self.y, other.y))
        return width * height

    def contains(self, other: "Box", tolerance: float = 0.03) -> bool:
        return (
            self.x <= other.x + tolerance
            and self.y <= other.y + tolerance
            and self.right >= other.right - tolerance
            and self.bottom >= other.bottom - tolerance
        )


@dataclass(frozen=True)
class CoordinateMap:
    origin_x: float = 0.0
    origin_y: float = 0.0
    scale_x: float = 1.0
    scale_y: float = 1.0
    child_origin_x: float = 0.0
    child_origin_y: float = 0.0

    def convert_box(
        self, x: float, y: float, width: float, height: float
    ) -> Box:
        absolute_x = self.origin_x + (x - self.child_origin_x) * self.scale_x
        absolute_y = self.origin_y + (y - self.child_origin_y) * self.scale_y
        return Box(
            absolute_x / EMU_PER_INCH,
            absolute_y / EMU_PER_INCH,
            width * self.scale_x / EMU_PER_INCH,
            height * self.scale_y / EMU_PER_INCH,
        )


@dataclass
class ShapeInfo:
    name: str
    kind: str
    box: Box
    text: str
    role: str
    font_sizes: list[float]
    font_names: list[str]
    margins: tuple[float, float, float, float]
    background: bool
    footer: bool

    @property
    def has_text(self) -> bool:
        return bool(self.text.strip())

    @property
    def max_font_size(self) -> float | None:
        return max(self.font_sizes) if self.font_sizes else None

    @property
    def min_font_size(self) -> float | None:
        return min(self.font_sizes) if self.font_sizes else None


@dataclass
class Issues:
    failures: dict[str, list[str]] = field(
        default_factory=lambda: {"gate1": [], "gate2": [], "gate3": []}
    )
    warnings: dict[str, list[str]] = field(
        default_factory=lambda: {"gate1": [], "gate2": [], "gate3": []}
    )

    def fail(self, gate: str, message: str) -> None:
        self.failures[gate].append(message)

    def warn(self, gate: str, message: str) -> None:
        self.warnings[gate].append(message)

    def deduplicate(self) -> None:
        for collection in (self.failures, self.warnings):
            for gate, values in collection.items():
                collection[gate] = list(dict.fromkeys(values))

    @property
    def failure_count(self) -> int:
        return sum(len(values) for values in self.failures.values())

    @property
    def warning_count(self) -> int:
        return sum(len(values) for values in self.warnings.values())


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def slide_number(name: str) -> int:
    match = re.search(r"slide(\d+)\.xml$", name)
    return int(match.group(1)) if match else 0


def cjk_count(text: str) -> int:
    return len(re.findall(r"[\u3400-\u9fff]", text))


def integer_attribute(node: ET.Element | None, name: str, default: int = 0) -> int:
    if node is None:
        return default
    value = node.get(name)
    try:
        return int(value) if value is not None else default
    except ValueError:
        return default


def resolve_target(source_part: str, target: str) -> str:
    normalized_target = target.replace("\\", "/")
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", normalized_target):
        return normalized_target
    source_dir = posixpath.dirname(source_part)
    return posixpath.normpath(posixpath.join(source_dir, normalized_target)).lstrip("/")


def relationships_path(part_name: str) -> str:
    path = PurePosixPath(part_name)
    return str(path.parent / "_rels" / f"{path.name}.rels")


def parse_relationships(xml_bytes: bytes) -> list[dict[str, str]]:
    root = ET.fromstring(xml_bytes)
    relationships: list[dict[str, str]] = []
    for node in root.findall(f"{{{REL_NS}}}Relationship"):
        relationships.append(dict(node.attrib))
    return relationships


def validate_internal_relationships(
    archive: zipfile.ZipFile,
    source_part: str,
    names: set[str],
    issues: Issues,
) -> None:
    rels_name = relationships_path(source_part)
    if rels_name not in names:
        issues.fail("gate1", f"{source_part}: missing relationship file")
        return
    try:
        relationships = parse_relationships(archive.read(rels_name))
    except ET.ParseError as error:
        issues.fail("gate1", f"{rels_name}: invalid XML ({error})")
        return
    for relationship in relationships:
        if relationship.get("TargetMode") == "External":
            continue
        target = relationship.get("Target")
        if not target:
            issues.fail("gate1", f"{rels_name}: relationship without a target")
            continue
        resolved = resolve_target(source_part, target)
        if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", resolved):
            continue
        if resolved not in names:
            issues.fail(
                "gate1",
                f"{source_part}: relationship target is missing ({resolved})",
            )


def inspect_archive(
    archive: zipfile.ZipFile, issues: Issues
) -> tuple[list[str], float, float]:
    names = set(archive.namelist())
    for required in ("[Content_Types].xml", "ppt/presentation.xml"):
        if required not in names:
            issues.fail("gate1", f"missing required PPTX part: {required}")

    bad_member = archive.testzip()
    if bad_member:
        issues.fail("gate1", f"corrupt ZIP member: {bad_member}")

    try:
        if "[Content_Types].xml" in names:
            ET.fromstring(archive.read("[Content_Types].xml"))
    except ET.ParseError as error:
        issues.fail("gate1", f"[Content_Types].xml: invalid XML ({error})")

    presentation_root: ET.Element | None = None
    if "ppt/presentation.xml" in names:
        try:
            presentation_root = ET.fromstring(archive.read("ppt/presentation.xml"))
        except ET.ParseError as error:
            issues.fail("gate1", f"ppt/presentation.xml: invalid XML ({error})")

    width = DEFAULT_SLIDE_WIDTH
    height = DEFAULT_SLIDE_HEIGHT
    if presentation_root is not None:
        slide_size = presentation_root.find("p:sldSz", NS)
        if slide_size is not None:
            width = integer_attribute(slide_size, "cx") / EMU_PER_INCH
            height = integer_attribute(slide_size, "cy") / EMU_PER_INCH
        else:
            issues.warn(
                "gate1",
                "presentation slide size is inherited or missing; using 13.333 × 7.5 inches",
            )

    ordered_slides: list[str] = []
    rels_name = relationships_path("ppt/presentation.xml")
    relation_map: dict[str, str] = {}
    if rels_name in names:
        try:
            for relationship in parse_relationships(archive.read(rels_name)):
                relation_id = relationship.get("Id")
                target = relationship.get("Target")
                if relation_id and target and relationship.get("TargetMode") != "External":
                    relation_map[relation_id] = resolve_target(
                        "ppt/presentation.xml", target
                    )
        except ET.ParseError as error:
            issues.fail("gate1", f"{rels_name}: invalid XML ({error})")
    else:
        issues.fail("gate1", f"missing required PPTX part: {rels_name}")

    if presentation_root is not None:
        for slide_id in presentation_root.findall("p:sldIdLst/p:sldId", NS):
            relation_id = slide_id.get(f"{{{NS['r']}}}id")
            target = relation_map.get(relation_id or "")
            if not relation_id or not target:
                issues.fail(
                    "gate1",
                    "presentation contains a slide without a valid relationship",
                )
                continue
            if target not in names:
                issues.fail("gate1", f"presentation references missing slide: {target}")
                continue
            ordered_slides.append(target)

    if not ordered_slides:
        ordered_slides = sorted(
            (
                name
                for name in names
                if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)
            ),
            key=slide_number,
        )

    if not ordered_slides:
        issues.fail("gate1", "no slide XML found")
    if len(ordered_slides) != len(set(ordered_slides)):
        issues.fail("gate1", "presentation references the same slide more than once")

    for slide_name in ordered_slides:
        validate_internal_relationships(archive, slide_name, names, issues)

    return ordered_slides, width, height


def extract_raw_box(element: ET.Element) -> tuple[float, float, float, float] | None:
    transform = element.find("p:spPr/a:xfrm", NS)
    if transform is None:
        transform = element.find("p:xfrm", NS)
    if transform is None:
        return None
    offset = transform.find("a:off", NS)
    extent = transform.find("a:ext", NS)
    if offset is None or extent is None:
        return None
    return (
        float(integer_attribute(offset, "x")),
        float(integer_attribute(offset, "y")),
        float(integer_attribute(extent, "cx")),
        float(integer_attribute(extent, "cy")),
    )


def group_coordinate_map(
    group: ET.Element, parent: CoordinateMap
) -> CoordinateMap | None:
    transform = group.find("p:grpSpPr/a:xfrm", NS)
    if transform is None:
        return None
    offset = transform.find("a:off", NS)
    extent = transform.find("a:ext", NS)
    child_offset = transform.find("a:chOff", NS)
    child_extent = transform.find("a:chExt", NS)
    if None in (offset, extent, child_offset, child_extent):
        return None
    child_width = integer_attribute(child_extent, "cx")
    child_height = integer_attribute(child_extent, "cy")
    if child_width <= 0 or child_height <= 0:
        return None

    group_x = (
        parent.origin_x
        + (integer_attribute(offset, "x") - parent.child_origin_x) * parent.scale_x
    )
    group_y = (
        parent.origin_y
        + (integer_attribute(offset, "y") - parent.child_origin_y) * parent.scale_y
    )
    group_width = integer_attribute(extent, "cx") * parent.scale_x
    group_height = integer_attribute(extent, "cy") * parent.scale_y
    return CoordinateMap(
        origin_x=group_x,
        origin_y=group_y,
        scale_x=group_width / child_width,
        scale_y=group_height / child_height,
        child_origin_x=float(integer_attribute(child_offset, "x")),
        child_origin_y=float(integer_attribute(child_offset, "y")),
    )


def iter_positioned_elements(
    container: ET.Element,
    coordinate_map: CoordinateMap,
) -> list[tuple[ET.Element, str, Box]]:
    positioned: list[tuple[ET.Element, str, Box]] = []
    for element in list(container):
        kind = local_name(element.tag)
        if kind == "grpSp":
            child_map = group_coordinate_map(element, coordinate_map)
            positioned.extend(
                iter_positioned_elements(element, child_map or coordinate_map)
            )
            continue
        if kind not in {"sp", "pic", "graphicFrame", "cxnSp"}:
            continue
        raw_box = extract_raw_box(element)
        if raw_box is None:
            continue
        box = coordinate_map.convert_box(*raw_box)
        positioned.append((element, kind, box))
    return positioned


def shape_name(element: ET.Element, kind: str) -> str:
    property_node = element.find(".//p:cNvPr", NS)
    if property_node is not None:
        name = property_node.get("name")
        if name:
            return name
        identifier = property_node.get("id")
        if identifier:
            return f"{kind}-{identifier}"
    return kind


def shape_text(element: ET.Element, kind: str) -> str:
    text_body = element.find("p:txBody", NS)
    if text_body is not None:
        paragraphs: list[str] = []
        for paragraph in text_body.findall("a:p", NS):
            text = "".join(node.text or "" for node in paragraph.findall(".//a:t", NS))
            if text:
                paragraphs.append(text)
        return "\n".join(paragraphs)
    if kind == "graphicFrame":
        return "\n".join(
            node.text or "" for node in element.findall(".//a:t", NS) if node.text
        )
    return ""


def shape_font_sizes(element: ET.Element) -> list[float]:
    sizes: list[float] = []
    for path in (".//a:rPr", ".//a:defRPr", ".//a:endParaRPr"):
        for properties in element.findall(path, NS):
            value = properties.get("sz")
            if value and value.isdigit():
                sizes.append(int(value) / 100.0)
    return sizes


def shape_font_names(element: ET.Element) -> list[str]:
    names: list[str] = []
    for path in (".//a:latin", ".//a:ea", ".//a:cs"):
        for font in element.findall(path, NS):
            typeface = font.get("typeface")
            if typeface and not typeface.startswith("+"):
                names.append(typeface)
    return list(dict.fromkeys(names))


def shape_margins(element: ET.Element) -> tuple[float, float, float, float]:
    body_properties = element.find("p:txBody/a:bodyPr", NS)
    defaults = {
        "lIns": 91440,
        "rIns": 91440,
        "tIns": 45720,
        "bIns": 45720,
    }
    values = [
        integer_attribute(body_properties, name, default)
        for name, default in defaults.items()
    ]
    return tuple(value / EMU_PER_INCH for value in values)  # type: ignore[return-value]


def classify_role(
    element: ET.Element,
    name: str,
    kind: str,
    box: Box,
    text: str,
    max_font_size: float | None,
    slide_index: int,
    slide_height: float,
) -> str:
    placeholder = element.find(".//p:ph", NS)
    placeholder_type = placeholder.get("type", "") if placeholder is not None else ""
    lowered_name = name.casefold()
    if placeholder_type in {"title", "ctrTitle"}:
        return "cover" if slide_index == 1 else "title"
    if placeholder_type == "subTitle":
        return "subtitle"
    if placeholder_type in {"dt", "ftr", "sldNum"}:
        return "footer"
    if kind == "graphicFrame":
        return "table"
    if "title" in lowered_name or "標題" in lowered_name:
        return "cover" if slide_index == 1 else "title"
    if box.bottom >= slide_height - 0.15 and box.height <= 0.65:
        return "footer"
    if (
        slide_index == 1
        and box.y < slide_height * 0.45
        and (max_font_size or 0) >= 30
    ):
        return "cover"
    if box.y < slide_height * 0.28 and (max_font_size or 0) >= 28:
        return "title"
    if (max_font_size or 0) >= 32 and len(text) <= 120:
        return "key"
    if (
        (max_font_size or 0) <= 16
        and len(text.strip()) <= 24
        and box.height <= 0.55
    ):
        return "label"
    return "body"


def build_shape_info(
    element: ET.Element,
    kind: str,
    box: Box,
    slide_index: int,
    slide_width: float,
    slide_height: float,
) -> ShapeInfo:
    name = shape_name(element, kind)
    text = shape_text(element, kind)
    font_sizes = shape_font_sizes(element)
    max_font_size = max(font_sizes) if font_sizes else None
    role = classify_role(
        element,
        name,
        kind,
        box,
        text,
        max_font_size,
        slide_index,
        slide_height,
    )
    lowered_name = name.casefold()
    background = (
        box.area >= slide_width * slide_height * 0.75
        or "background" in lowered_name
        or "背景" in lowered_name
    )
    footer = role == "footer" or (
        box.y >= slide_height - 0.8
        and box.height <= 0.65
        and (max_font_size or 0) <= 14
    )
    return ShapeInfo(
        name=name,
        kind=kind,
        box=box,
        text=text,
        role=role,
        font_sizes=font_sizes,
        font_names=shape_font_names(element),
        margins=shape_margins(element),
        background=background,
        footer=footer,
    )


def inspect_text_and_geometry(
    shapes: list[ShapeInfo],
    slide_index: int,
    slide_width: float,
    slide_height: float,
    mode: str,
    min_margin: float,
    fit_slack: float,
    issues: Issues,
) -> None:
    slide_text = "\n".join(shape.text for shape in shapes if shape.has_text)
    lowered_slide_text = slide_text.casefold()
    for marker in DRAFT_MARKERS:
        if marker.casefold() in lowered_slide_text:
            message = f"Slide {slide_index}: contains draft marker {marker!r}"
            if mode == "final":
                issues.fail("gate1", message)
            else:
                issues.warn("gate1", message)

    for shape in shapes:
        box = shape.box
        tolerance = 0.02
        outside = (
            box.x < -tolerance
            or box.y < -tolerance
            or box.right > slide_width + tolerance
            or box.bottom > slide_height + tolerance
        )
        if outside:
            message = (
                f"Slide {slide_index}: {shape.name!r} extends beyond slide bounds "
                f"({box.x:.2f}, {box.y:.2f}, {box.width:.2f}, {box.height:.2f} in)"
            )
            if shape.has_text and mode == "final":
                issues.fail("gate2", message)
            else:
                issues.warn("gate2", message)

        if shape.has_text and not shape.background and not shape.footer:
            edge_gap = min(
                box.x,
                box.y,
                slide_width - box.right,
                slide_height - box.bottom,
            )
            if edge_gap < min_margin:
                issues.warn(
                    "gate2",
                    f"Slide {slide_index}: {shape.name!r} has only "
                    f"{edge_gap:.2f} in edge clearance",
                )

        if not shape.has_text:
            continue

        paragraphs = [line.strip() for line in shape.text.splitlines() if line.strip()]
        if (
            shape.kind == "sp"
            and len(paragraphs) >= 2
            and 1 <= cjk_count(paragraphs[-1]) <= 3
            and len(paragraphs[-1]) <= 5
        ):
            issues.warn(
                "gate2",
                f"Slide {slide_index}: {shape.name!r} has a possible orphan "
                f"line {paragraphs[-1]!r}",
            )

        maximum = shape.max_font_size
        minimum = shape.min_font_size
        if maximum is not None and maximum > 64:
            issues.warn(
                "gate2",
                f"Slide {slide_index}: {shape.name!r} exceeds 64 pt ({maximum:g} pt)",
            )
        if shape.role == "title" and maximum is not None and maximum > 44:
            issues.warn(
                "gate2",
                f"Slide {slide_index}: title {shape.name!r} exceeds 44 pt "
                f"({maximum:g} pt)",
            )
        if (
            shape.role in {"body", "table"}
            and minimum is not None
            and (len(shape.text.strip()) >= 24 or len(paragraphs) >= 2)
        ):
            if minimum < 14 and mode == "final":
                issues.fail(
                    "gate2",
                    f"Slide {slide_index}: {shape.name!r} uses {minimum:g} pt "
                    "for meaningful content",
                )
            elif minimum < 18:
                issues.warn(
                    "gate2",
                    f"Slide {slide_index}: {shape.name!r} uses body text below "
                    f"18 pt ({minimum:g} pt)",
                )

        if (
            shape.kind == "sp"
            and maximum is not None
            and box.width > 0.2
            and box.height > 0.15
        ):
            left, right, top, bottom = shape.margins
            available_width = max(0.05, box.width - left - right)
            available_height = max(0.05, box.height - top - bottom)
            result = evaluate_font_size(
                shape.text,
                maximum,
                available_width,
                available_height,
                role=shape.role,
                slack=fit_slack,
            )
            fit_relevant = result.estimated_lines >= 2 or len(shape.text.strip()) >= 24
            if result.fill_ratio > 1.0 and fit_relevant:
                message = (
                    f"Slide {slide_index}: {shape.name!r} has text-fit risk "
                    f"(estimated {result.estimated_lines} lines, "
                    f"{result.fill_ratio:.2f}× available height)"
                )
                if result.fill_ratio >= 1.2 and mode == "final":
                    issues.fail("gate2", message)
                else:
                    issues.warn("gate2", message)
            elif result.fill_ratio >= 0.92 and fit_relevant:
                issues.warn(
                    "gate2",
                    f"Slide {slide_index}: {shape.name!r} is near text-box "
                    f"capacity ({result.fill_ratio:.2f})",
                )

            if shape.role in {"cover", "title"}:
                line_limit = 3 if shape.role == "cover" else 2
                if result.estimated_lines > line_limit:
                    issues.warn(
                        "gate2",
                        f"Slide {slide_index}: {shape.role} {shape.name!r} is "
                        f"estimated at {result.estimated_lines} lines "
                        f"(limit {line_limit})",
                    )

    candidates = [
        shape
        for shape in shapes
        if not shape.background and shape.box.area >= 0.02 and shape.kind != "cxnSp"
    ]
    for index, first in enumerate(candidates):
        for second in candidates[index + 1 :]:
            intersection = first.box.intersection(second.box)
            if intersection <= 0.02:
                continue
            if first.box.contains(second.box) or second.box.contains(first.box):
                continue
            smaller_area = min(first.box.area, second.box.area)
            overlap_ratio = intersection / max(smaller_area, 0.001)
            if first.has_text and second.has_text and overlap_ratio >= 0.12:
                issues.warn(
                    "gate2",
                    f"Slide {slide_index}: possible text overlap between "
                    f"{first.name!r} and {second.name!r} ({overlap_ratio:.0%})",
                )
            elif (
                (first.has_text and second.kind == "pic")
                or (second.has_text and first.kind == "pic")
            ) and overlap_ratio >= 0.35:
                issues.warn(
                    "gate2",
                    f"Slide {slide_index}: text/image overlay between "
                    f"{first.name!r} and {second.name!r}; confirm intent and contrast",
                )


def inspect_slide(
    xml_bytes: bytes,
    slide_index: int,
    slide_width: float,
    slide_height: float,
    mode: str,
    min_margin: float,
    fit_slack: float,
    issues: Issues,
) -> None:
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as error:
        issues.fail("gate1", f"Slide {slide_index}: invalid XML ({error})")
        return
    shape_tree = root.find("p:cSld/p:spTree", NS)
    if shape_tree is None:
        issues.fail("gate1", f"Slide {slide_index}: missing shape tree")
        return
    positioned = iter_positioned_elements(shape_tree, CoordinateMap())
    shapes = [
        build_shape_info(
            element,
            kind,
            box,
            slide_index,
            slide_width,
            slide_height,
        )
        for element, kind, box in positioned
    ]
    inspect_text_and_geometry(
        shapes,
        slide_index,
        slide_width,
        slide_height,
        mode,
        min_margin,
        fit_slack,
        issues,
    )


def inspect_render_gate(
    pptx: Path,
    slide_count: int,
    render_dir: Path | None,
    pdf: Path | None,
    visual_review_pass: bool,
    mode: str,
    issues: Issues,
) -> None:
    images: list[Path] = []
    if render_dir is not None:
        if not render_dir.is_dir():
            issues.fail("gate3", f"render directory not found: {render_dir}")
        else:
            images = sorted(
                path
                for path in render_dir.rglob("*")
                if path.is_file() and path.suffix.casefold() in {".png", ".jpg", ".jpeg"}
            )
            if len(images) < slide_count:
                issues.fail(
                    "gate3",
                    f"render directory has {len(images)} image(s) for "
                    f"{slide_count} slide(s)",
                )
            elif len(images) > slide_count:
                issues.warn(
                    "gate3",
                    f"render directory has {len(images)} images for "
                    f"{slide_count} slides; remove stale or collage images",
                )
            empty_images = [path.name for path in images if path.stat().st_size == 0]
            if empty_images:
                issues.fail(
                    "gate3",
                    "render directory contains empty image files: "
                    + ", ".join(empty_images[:5]),
                )
            stale_images = [
                path.name
                for path in images
                if path.stat().st_mtime + 1.0 < pptx.stat().st_mtime
            ]
            if stale_images:
                issues.fail(
                    "gate3",
                    "rendered images are older than the current PPTX: "
                    + ", ".join(stale_images[:5]),
                )
    elif mode == "final":
        issues.fail(
            "gate3",
            "final mode requires --render-dir with one full-size image per slide",
        )

    if pdf is not None:
        if not pdf.is_file() or pdf.stat().st_size == 0:
            issues.fail("gate3", f"PDF missing or empty: {pdf}")
        elif pdf.stat().st_mtime + 1.0 < pptx.stat().st_mtime:
            issues.fail(
                "gate3",
                f"PDF is older than the current PPTX and must be regenerated: {pdf}",
            )
    elif mode == "final":
        issues.fail("gate3", "final mode requires --pdf generated from the current PPTX")

    if mode == "final" and not visual_review_pass:
        issues.fail(
            "gate3",
            "final mode requires --visual-review-pass after full-size slide inspection",
        )


def print_results(issues: Issues, fail_on_warning: bool) -> int:
    issues.deduplicate()
    if fail_on_warning and issues.warning_count:
        for gate, values in issues.warnings.items():
            for value in values:
                issues.fail(gate, f"strict mode: {value}")
        issues.warnings = {"gate1": [], "gate2": [], "gate3": []}
        issues.deduplicate()

    gate_names = {
        "gate1": "structure/content",
        "gate2": "geometry/text",
        "gate3": "render/visual",
    }
    for gate in ("gate1", "gate2", "gate3"):
        for item in issues.warnings[gate]:
            print(f"WARNING [{gate_names[gate]}]: {item}")
        for item in issues.failures[gate]:
            print(f"FAIL [{gate_names[gate]}]: {item}")

    for gate in ("gate1", "gate2", "gate3"):
        print(
            f"{gate.upper()} {gate_names[gate]}: "
            f"{len(issues.failures[gate])} failure(s), "
            f"{len(issues.warnings[gate])} warning(s)"
        )

    if issues.failure_count:
        print(
            f"RESULT: failed with {issues.failure_count} issue(s) and "
            f"{issues.warning_count} warning(s)"
        )
        return 1
    print(f"RESULT: passed with {issues.warning_count} warning(s)")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run three-stage PowerPoint quality checks."
    )
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--mode", choices=("draft", "final"), default="final")
    parser.add_argument("--render-dir", type=Path)
    parser.add_argument("--pdf", type=Path)
    parser.add_argument("--visual-review-pass", action="store_true")
    parser.add_argument("--min-margin", type=float, default=0.3)
    parser.add_argument("--fit-slack", type=float, default=0.12)
    parser.add_argument("--fail-on-warning", action="store_true")
    args = parser.parse_args()

    if not args.pptx.is_file():
        print(f"ERROR: file not found: {args.pptx}", file=sys.stderr)
        return 2
    if args.min_margin < 0:
        parser.error("--min-margin cannot be negative")
    if not 0 <= args.fit_slack < 0.5:
        parser.error("--fit-slack must be between 0 and 0.5")

    issues = Issues()
    if args.mode == "final" and re.search(
        r"(?:^|[_\-\s])(draft|草稿)(?:$|[_\-\s])",
        args.pptx.stem,
        flags=re.IGNORECASE,
    ):
        issues.fail(
            "gate1",
            "final mode cannot be used with a DRAFT／草稿 filename",
        )
    try:
        with zipfile.ZipFile(args.pptx) as archive:
            slides, slide_width, slide_height = inspect_archive(archive, issues)
            for index, name in enumerate(slides, start=1):
                inspect_slide(
                    archive.read(name),
                    index,
                    slide_width,
                    slide_height,
                    args.mode,
                    args.min_margin,
                    args.fit_slack,
                    issues,
                )
    except zipfile.BadZipFile:
        print("ERROR: invalid PPTX/ZIP file", file=sys.stderr)
        return 2
    except OSError as error:
        print(f"ERROR: cannot read PPTX: {error}", file=sys.stderr)
        return 2

    inspect_render_gate(
        args.pptx,
        len(slides),
        args.render_dir,
        args.pdf,
        args.visual_review_pass,
        args.mode,
        issues,
    )
    return print_results(issues, args.fail_on_warning)


if __name__ == "__main__":
    raise SystemExit(main())
