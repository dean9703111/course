#!/usr/bin/env python3
"""Estimate a safe PowerPoint font size for a text box.

The estimator is intentionally conservative and supports mixed Chinese/Latin
text without requiring a particular presentation library. Actual rendering
remains the final source of truth.
"""

from __future__ import annotations

import argparse
import json
import math
import re
from dataclasses import asdict, dataclass
from pathlib import Path


POINTS_PER_INCH = 72.0

ROLE_RANGES: dict[str, tuple[float, float]] = {
    "cover": (44.0, 60.0),
    "title": (30.0, 40.0),
    "key": (32.0, 48.0),
    "card-title": (22.0, 28.0),
    "body": (18.0, 24.0),
    "note": (14.0, 18.0),
}


@dataclass(frozen=True)
class FitResult:
    recommended_font_size: float
    estimated_lines: int
    required_height_pt: float
    available_height_pt: float
    fill_ratio: float
    fits: bool
    role: str
    slack: float


def glyph_units(character: str) -> float:
    """Return an approximate width in em units for one character."""
    codepoint = ord(character)
    if (
        0x3400 <= codepoint <= 0x9FFF
        or 0xF900 <= codepoint <= 0xFAFF
        or 0x3000 <= codepoint <= 0x303F
        or 0xFF00 <= codepoint <= 0xFFEF
    ):
        return 1.0
    if character.isspace():
        return 0.32
    if character.isupper():
        return 0.66
    if character.islower() or character.isdigit():
        return 0.56
    if re.match(r"[.,:;!?\-–—'\"()\[\]{}]", character):
        return 0.36
    return 0.9


def text_units(text: str, font_factor: float = 1.0) -> float:
    return sum(glyph_units(character) for character in text) * font_factor


def estimate_line_count(
    text: str,
    font_size: float,
    width_in: float,
    *,
    slack: float = 0.12,
    font_factor: float = 1.0,
) -> int:
    """Estimate wrapped line count using conservative glyph widths."""
    usable_width_pt = max(width_in * POINTS_PER_INCH * (1.0 - slack), 1.0)
    capacity_em = usable_width_pt / max(font_size, 1.0)
    lines = 0
    for logical_line in text.replace("\r", "").split("\n"):
        if not logical_line:
            lines += 1
            continue
        units = text_units(logical_line, font_factor)
        if re.match(r"^\s*(?:[-+*•]|\d+[.)])\s+", logical_line):
            units *= 1.08
        lines += max(1, math.ceil(units / max(capacity_em, 0.1)))
    return max(lines, 1)


def evaluate_font_size(
    text: str,
    font_size: float,
    width_in: float,
    height_in: float,
    *,
    role: str = "body",
    slack: float = 0.12,
    line_height: float = 1.15,
    paragraph_spacing: float = 0.14,
    font_factor: float = 1.0,
) -> FitResult:
    lines = estimate_line_count(
        text,
        font_size,
        width_in,
        slack=slack,
        font_factor=font_factor,
    )
    nonempty_paragraphs = [line for line in text.splitlines() if line.strip()]
    extra_paragraphs = max(0, len(nonempty_paragraphs) - 1)
    effective_line_height = 1.0 if lines == 1 else line_height
    required_height = (
        lines * font_size * effective_line_height
        + extra_paragraphs * font_size * paragraph_spacing
    )
    available_height = max(height_in * POINTS_PER_INCH * (1.0 - slack), 1.0)
    ratio = required_height / available_height
    return FitResult(
        recommended_font_size=font_size,
        estimated_lines=lines,
        required_height_pt=round(required_height, 2),
        available_height_pt=round(available_height, 2),
        fill_ratio=round(ratio, 3),
        fits=ratio <= 1.0,
        role=role,
        slack=slack,
    )


def recommend_font_size(
    text: str,
    width_in: float,
    height_in: float,
    *,
    role: str = "body",
    min_font_size: float | None = None,
    max_font_size: float | None = None,
    slack: float = 0.12,
    line_height: float = 1.15,
    font_factor: float = 1.0,
) -> FitResult:
    role_min, role_max = ROLE_RANGES[role]
    minimum = role_min if min_font_size is None else min_font_size
    maximum = role_max if max_font_size is None else max_font_size
    if minimum <= 0 or maximum < minimum:
        raise ValueError("font-size range is invalid")
    if width_in <= 0 or height_in <= 0:
        raise ValueError("text-box width and height must be positive")
    if not 0 <= slack < 0.5:
        raise ValueError("slack must be between 0 and 0.5")

    steps = int(round((maximum - minimum) * 2))
    for index in range(steps + 1):
        size = maximum - index * 0.5
        result = evaluate_font_size(
            text,
            size,
            width_in,
            height_in,
            role=role,
            slack=slack,
            line_height=line_height,
            font_factor=font_factor,
        )
        if result.fits:
            return result

    return evaluate_font_size(
        text,
        minimum,
        width_in,
        height_in,
        role=role,
        slack=slack,
        line_height=line_height,
        font_factor=font_factor,
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Estimate a safe PowerPoint font size for a text box."
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--text")
    source.add_argument("--text-file", type=Path)
    parser.add_argument("--width", type=float, required=True, help="text-box width in inches")
    parser.add_argument("--height", type=float, required=True, help="text-box height in inches")
    parser.add_argument("--role", choices=tuple(ROLE_RANGES), default="body")
    parser.add_argument("--min-font-size", type=float)
    parser.add_argument("--max-font-size", type=float)
    parser.add_argument("--slack", type=float, default=0.12)
    parser.add_argument("--line-height", type=float, default=1.15)
    parser.add_argument(
        "--font-factor",
        type=float,
        default=1.0,
        help="width multiplier for a wider or narrower target font",
    )
    parser.add_argument("--json", action="store_true", dest="as_json")
    args = parser.parse_args()

    text = args.text
    if args.text_file:
        text = args.text_file.read_text(encoding="utf-8")
    assert text is not None

    try:
        result = recommend_font_size(
            text,
            args.width,
            args.height,
            role=args.role,
            min_font_size=args.min_font_size,
            max_font_size=args.max_font_size,
            slack=args.slack,
            line_height=args.line_height,
            font_factor=args.font_factor,
        )
    except ValueError as error:
        parser.error(str(error))

    if args.as_json:
        print(json.dumps(asdict(result), ensure_ascii=False, indent=2))
    else:
        print(f"recommended_font_size={result.recommended_font_size:g}")
        print(f"estimated_lines={result.estimated_lines}")
        print(f"required_height_pt={result.required_height_pt:g}")
        print(f"available_height_pt={result.available_height_pt:g}")
        print(f"fill_ratio={result.fill_ratio:g}")
        print(f"fits={'yes' if result.fits else 'no'}")
    return 0 if result.fits else 1


if __name__ == "__main__":
    raise SystemExit(main())
