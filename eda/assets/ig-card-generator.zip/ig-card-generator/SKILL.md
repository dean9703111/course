---
name: ig-card-generator
description: 把知識素材（文章、講稿、筆記、逐字稿，或只有一個主題）提煉成 IG 輪播知識圖卡：封面 hook → 每卡一概念 → 結尾 CTA。以約定 Markdown DSL 撰寫，經 lint（criteria 全過）後由 build script 產出 1080×1350 PNG 系列圖（支援深／淺色主題）。當使用者說「做 IG 圖卡」「知識圖卡」「輪播圖」「carousel」「把這篇做成圖卡」「IG 貼文圖」「圖卡系列」時使用。出圖完成後可銜接 promo-writer 產生貼文 caption。
---

# IG Card Generator

素材 → 提煉（hook＋排卡）→ `content.md`（DSL）→ `node scripts/lint.mjs <dir>` 全過 → `node scripts/build.mjs <dir>` → `assets/cards/<theme>/NN.png` →（選用）promo-writer 產 caption

## 專案結構

```
.agents/skills/ig-card-generator/
├── SKILL.md
├── scripts/
│   ├── dsl.mjs        # DSL 解析＋渲染（build / lint 共用）
│   ├── config.mjs     # 兩層 config 載入（global → deck → frontmatter）
│   ├── lint.mjs       # criteria 檢查（可獨立執行）
│   └── build.mjs      # index.html + Puppeteer 逐卡出 PNG
├── reference/
│   ├── base.html          # 渲染模板（design token + 元件 CSS）
│   ├── hooks.md           # Hook 公式庫、排卡模板、每卡規則、CTA 公式
│   ├── content-example.md # 完整 DSL 範例
│   └── config-example.yaml
└── example/               # 可直接 build 的煙霧測試 deck
    ├── config/global.yaml
    └── skill-plugin-mcp/{config.yaml, content.md}

<root>/
├── config/global.yaml     # 品牌層（handle、theme、accent/hot、background、avatar、criteria）
└── <deck-dir>/
    ├── config.yaml        # 本副牌覆蓋（選用）
    ├── content.md         # DSL 內容
    ├── index.html         # build 產出（瀏覽器預覽，右下角切深淺色）
    ├── caption.md         # promo-writer 產出（選用）
    └── assets/cards/{dark,light}/NN.png
```

## Workflow

### Step 0：判斷輸入類型

| 情境 | 判斷依據 | 行動 |
|------|----------|------|
| 只有主題 | 一句話主題，無素材 | 先反問 1–2 題（受眾是誰？CTA 要導去哪？），再進 Step 1 |
| 有素材 | 文章／講稿／筆記／逐字稿 | 直接進 Step 1；若素材是單一檔案，deck 預設建立在素材同層的 `ig-card/` |
| 有現有目錄 | 指定既有 deck 資料夾 | 讀取後依需求修 content.md，跳 Step 3 |

### Step 1：提煉（產 content.md 之前，先想清楚）

讀 [hooks.md](reference/hooks.md)，產出**提煉摘要**給使用者確認（素材非常明確時可直接進 Step 2，但摘要仍要在回覆中列出）：

1. **核心主張**：一句話。這副牌只為這句話服務。
2. **受眾**：誰滑到會停下來。
3. **封面共鳴句**：先從素材找「讀者心裡話」或真實痛點，不先寫作者結論；說明為什麼這句會讓目標受眾停下來。
4. **Hook 公式**：六選一＋一句理由。用到數字時，指出數字在素材的哪裡。
5. **排卡結構**：教學型／清單型／對比型 三選一，列出每張卡的一句話大綱（5–10 張）。

### Step 2：寫成 DSL content.md

依下方語法約定撰寫。核心轉換原則與 course-page-generator 相同：**萃取重點，不逐字轉錄**；內容盡量落在結構元件內，避免整卡裸段落。

#### DSL 語法約定

| 語法 | 用途 | 範例 |
|------|------|------|
| `===` | 分卡（獨立一行） | — |
| `@cover` `@point` `@code` `@cta` | 卡片類型（卡片第一行） | 第 1 張必為 cover、最後必為 cta |
| `[badge] 文字` | 頂部膠囊標籤 | `[badge] ⚡ Claude 生態系 · 2026` |
| `[big] 文字` | 一句話 punchline，整卡視覺主角 | `[big] AI 不是顧問，是==隊友==` |
| `[stamp] 文字` | 品牌章印／系列標籤，多用於 CTA | `[stamp] Dean 的 AI 開發工作流` |
| `# 大標` | H1，可連續多行堆疊 | 封面 hook 用 |
| `## 段標` | H2（自帶強調底線），**一卡限一個** | `## 先講結論` |
| 一般段落 | body 文字，連續行合併換行 | — |
| `1. **標題**：說明` | 編號卡盒 | — |
| `- **標題**：說明` | 條列卡盒 | — |
| `[ok] 文字` / `[no] 文字` | ✅／❌ 對照盒 | 對比型必備 |
| `[warn] 文字` | ⚠️ 警示條 | — |
| `[tip] 文字` | 💡 重點框 | 每卡的記憶點 |
| `[flow] A -> B -> *C` | 自適應流程卡；短流程橫向，長流程自動轉 stepper，`*` 開頭＝強調節點 | `[flow] Define -> Generate -> Eval -> *Fix` |
| `> 引言` | 引言框（可多行） | 金句收束用 |
| ` ```lang 檔名 ` | 程式碼視窗（窗控＋檔名列＋語法上色） | ` ```yaml SKILL.md ` |
| `***` | 裝飾分隔線 | — |
| `**重點**` | 強調色粗體（品牌 accent） | — |
| `==標記==` | 螢光標記膠囊 | 封面關鍵詞 |
| `!!衝擊!!` | 衝擊色（hook 數字、警告字） | `!!99%!!` |
| `` `code` `` | 行內程式碼 | — |

frontmatter（選填，覆蓋 config）：`title` / `handle` / `ratio` / `theme` / `background`。

### Step 3：Lint（criteria 全過才准出圖）

```bash
node .agents/skills/ig-card-generator/scripts/lint.mjs <deck-dir>
```

逐項輸出 pass/fail。**error 修到零、warning 逐條人工確認**後才進 Step 4。criteria 定義在 config 的 `criteria:` 區塊（= Define 這副牌「點先算對」的尺），主要項目：卡數 5–10、封面必含 hook 記號、一卡一概念、字數上限、CTA 必含行動動詞與留言「關鍵字」、禁用語（AI 腔）、未考證數字警告。

### Step 4：Build 出圖

```bash
node .agents/skills/ig-card-generator/scripts/build.mjs <deck-dir>              # 依 config 的 brand.theme
node .agents/skills/ig-card-generator/scripts/build.mjs <deck-dir> --theme both # 深淺各出一套
```

Build 會自動：跑 lint → 注入品牌 token → 產 `index.html` → Puppeteer **溢版檢查**（任何一張內容超出畫布即中止並指出卡號）→ 逐卡截 1080×1350 PNG（× `export.scale`）。溢版就回 Step 2 精簡文字或拆卡，不要用 `--force` 交差。

### Step 5：串 promo-writer 產 caption（使用者要發文時）

出圖完成後，改用 **promo-writer** skill，以本 deck 的 `content.md`（去除 DSL 記號後的內文）為素材產出貼文文案，並要求：

1. 開頭承接封面 hook（同一個承諾，不要另起爐灶）
2. 結尾回收 CTA 卡的**留言關鍵字**與追蹤 handle
3. 產出存 `<deck-dir>/caption.md`

## 內容鐵律

1. **禁止捏造**：統計數字、價格、案例必須出自素材或可考證；查無來源 → 換非數字 hook 或留 `<!-- TODO: 待補來源 -->`。lint 會對 `%`、`N 倍` 類數字發出警告，逐條確認。
2. **一卡一概念**：一張 @point 只有一個 `##`。想講兩件事就拆卡。
3. **禁 AI 腔**：criteria 的 `forbidden` 清單（可擴充），lint 強制。
4. **CTA 完整**：行動動詞＋留言「關鍵字」，關鍵字之後 caption 要回收。
5. **封面先共鳴**：封面不是摘要。主標優先用讀者會說出口的痛點句（「每天用 AI，怎麼還是沒變快？」），再用副標補轉折；避免用「流程、模型、工作流」這類抽象詞當第一眼主角。

## 視覺原則（品牌固定）

- 視覺識別**固定一套**：不新增任意 style pack、不在 content.md 內寫任何色碼或樣式。內容只寫語意（`**` `==` `!!` `[ok]`…），長相由 token 決定。
- 可調視覺變數只放 config：`brand.accent`、`brand.hot`、`brand.background`、`brand.avatar`、`brand.layout`。`accent` / `hot` 各含 dark/light 兩值；**深淺不是反轉是重新映射**——淺色模式的 accent 必須是深色（例：`#FFC24D` → `#7E570F`），確保米色底上對比 ≥ 4.5:1；`--on-acc` 由 build 依亮度自動計算。
- `brand.background` 控制整副牌背景風格，允許值：`minimal`（乾淨微光）、`grid`（科技格線）、`gradient`（大面積漸層）、`halo`（光圈＋層次，預設）。不要在單張卡片內改背景，避免視覺不一致。
- `brand.avatar.src` 可指定 CTA 最後一頁的圓形照片，路徑相對 deck 目錄，例如 `assets/avatar.jpg`；未設定或空字串時不顯示照片。照片只出現在 `@cta`，用來增加追蹤辨識度。
- 模板會依每張卡內容密度自動套用 `hero` / `airy` / `balanced` / `dense` 尺度，空間足夠時整組字級、元件、間距一起放大；內容較多時只小幅收斂。不要只為了放大單一標題而硬塞樣式，比例要整體一致。
- `brand.layout.mode` 控制社群視覺語氣：`tutorial` 穩定教學、`punchy` 強化停留、`editorial` 偏雜誌。`brand.layout.cover_visual: pain-flow` 會在封面加入痛點循環，預設是「問 AI → 複製貼上 → 自己修錯」；可用 `brand.layout.cover_steps` 依素材改成更準確的核心行為。`brand.layout.rhythm: varied` 會讓不同主元件卡片有更明顯的節奏差。若目標是增加停留與點進率，優先用 `punchy + pain-flow + varied`。
- 深色＝黑體科技感、淺色＝明體雜誌感（字體人格由 token 切換），這是設計的一部分，不要改。

## Config 兩層

| 檔案 | 用途 | 必要性 |
|------|------|--------|
| `config/global.yaml` | 品牌層：handle、theme、accent/hot、background、avatar、export、criteria | 首次建立一次（build 從 deck 目錄向上搜尋 ≤ 4 層） |
| `<deck-dir>/config.yaml` | 本副牌覆蓋（deep merge；arrays 整個取代） | 選用 |

完整範例：[config-example.yaml](reference/config-example.yaml)

## 依賴與 Troubleshooting

- 依賴：repo 內 `npm i -D yaml puppeteer`；claude.ai 沙盒則在工作目錄 `npm i yaml puppeteer-core`。
- **claude.ai 沙盒**：上傳後 skill 掛在唯讀路徑（`/mnt/skills/user/ig-card-generator/`），scripts 可直接從該路徑執行——依賴解析內建「工作目錄 fallback」，裝在 cwd 的 `node_modules` 也找得到。deck 目錄請建在可寫位置（如 `/home/claude/<deck>`），build 只往 deck 目錄寫檔，不會動到 skill 本體。
- **找不到 Chrome**：build 依序自動掃描 `PUPPETEER_EXECUTABLE_PATH` → macOS Chrome → `/usr/bin/chromium*` → `PUPPETEER_CACHE_DIR` → `~/.cache/puppeteer` → 所有 `/home/*/.cache/puppeteer`（root 執行沙盒時的常見位置，已內建，不再需要手動 export cache dir）。都沒有時才需手動指定 `PUPPETEER_EXECUTABLE_PATH`。
- **root 執行**：`--no-sandbox` 等旗標已內建於 launch args。
- **沙盒中文字型**：模板字體堆疊已含 `Noto Sans/Serif CJK TC`；若截圖出現豆腐字，安裝 `fonts-noto-cjk`。
- **煙霧測試**：`node scripts/build.mjs example/skill-plugin-mcp --theme both`（於 skill 目錄執行）應產出 6 張 × 2 主題。

## Reference Files

- Hook 公式與排卡模板：[hooks.md](reference/hooks.md)
- DSL 完整範例：[content-example.md](reference/content-example.md)
- Config 範例：[config-example.yaml](reference/config-example.yaml)
- 渲染模板：[base.html](reference/base.html)
