@cover
[badge] ⚡ Claude 生態系 · 2026

# !!90 秒!! 分清楚
# ==Skill、Plugin、MCP==

裝了一堆工具，卻說不出差在哪？
這 6 張卡，一次講完。

===
@point
## 先講結論

[flow] Skill -> Plugin -> MCP

1. **Skill**：一條指令＝一套固定流程
2. **Plugin**：一次安裝＝一整組工具
3. **MCP**：一個連接器＝接上真實服務

[tip] 記法——Skill 是招式、Plugin 是裝備包、MCP 是插座。

===
@point
## 什麼時候該包成 Skill？

同一件事重複做超過 !!3 次!!，就值得包起來。

[ok] 適合：格式固定、步驟明確、會一直重複
[no] 不適合：一次性任務、高度發散的討論

> 「先動手做，再回頭包裝」——
> 這是累積最快的方式。

===
@code
## Skill 的骨架，長這樣

```yaml SKILL.md
name: promo-writer
description: 把長文萃取乾貨，轉成宣傳貼文
trigger: 「幫我寫宣傳文」
steps:
  - 萃取重點        # 先抓乾貨
  - 套用語氣範本    # 保留個人風格
  - 自我檢查後輸出  # criteria 全過才交
```

[warn] description 寫太籠統，觸發就會失準。

===
@point
## 沒接 MCP 的 AI，只能「說」

接上之後，才能真的替你「做」：

- **Notion**：讀寫資料庫與文件
- **Gmail**：搜尋、分類、草擬信件
- **Calendar**：查空檔、直接建立行程

***

平常聊天感覺不到，==自動化==的那一刻全靠它。

===
@cta
# 覺得有用？

下一篇：我的 ==8 個自製 Skill== 全公開

追蹤不迷路
留言「!!SKILL!!」搶先拿清單
