#!/usr/bin/env node
/**
 * Course Page Generator
 *
 * Usage:
 *   node build.mjs <course-dir>            # auto-discover config + content
 *   node build.mjs <course-dir>/content.md  # explicit content path
 *
 * Config layering:
 *   1. config/global.yaml  (base — instructor, socials, footer, defaults)
 *   2. <course-dir>/config.yaml  (override — page, quotes, nav, etc.)
 *   Deep merge: course config wins on conflict, arrays are replaced not appended.
 *
 * Output: <course-dir>/index.html
 */

import { readFileSync, writeFileSync, existsSync, statSync, readdirSync, mkdirSync } from 'fs';
import { resolve, dirname, join, relative } from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';
import { deflateRawSync } from 'zlib';

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE_HTML = resolve(__dirname, '../reference/base.html');

// ─── Detect GitHub Pages base URL from git remote ───

function detectGitHubPagesBase(cwd) {
  try {
    const remoteUrl = execSync('git remote get-url origin', { cwd, encoding: 'utf-8' }).trim();
    // Match SSH: git@github.com:user/repo.git or HTTPS: https://github.com/user/repo.git
    const match = remoteUrl.match(/github\.com[:/]([^/]+)\/([^/.]+?)(?:\.git)?$/);
    if (match) {
      const [, owner, repo] = match;
      return `https://${owner}.github.io/${repo}`;
    }
  } catch { /* not a git repo or no remote */ }
  return null;
}

// ─── Deep merge (arrays replaced, objects merged) ───

function deepMerge(base, override) {
  if (!override) return base;
  if (!base) return override;
  if (typeof base !== 'object' || typeof override !== 'object') return override;
  if (Array.isArray(override)) return override;

  const result = { ...base };
  for (const key of Object.keys(override)) {
    if (key in result && typeof result[key] === 'object' && typeof override[key] === 'object'
      && !Array.isArray(result[key]) && !Array.isArray(override[key])) {
      result[key] = deepMerge(result[key], override[key]);
    } else {
      result[key] = override[key];
    }
  }
  return result;
}

// ─── Minimal YAML parser (handles our config structure without deps) ───

function unquote(s) {
  if (!s) return '';
  s = s.trim();
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    return s.slice(1, -1);
  }
  if (s === 'true') return true;
  if (s === 'false') return false;
  return s;
}

function parseYamlFull(text) {
  const cleanLines = text.split('\n').map(l => l.replace(/\s+$/, ''));
  return parseYamlBlock(cleanLines, 0, cleanLines.length, -1);
}

function parseYamlBlock(lines, start, end, parentIndent) {
  const result = {};
  let i = start;

  while (i < end) {
    const line = lines[i];

    if (line.trim() === '' || /^\s*#/.test(line)) { i++; continue; }

    const indent = line.search(/\S/);
    if (indent <= parentIndent) break;

    if (line.trim().startsWith('- ')) { i++; continue; }

    const kvMatch = line.trim().match(/^([\w]+):\s*(.*)/);
    if (!kvMatch) { i++; continue; }

    const key = kvMatch[1];
    let val = kvMatch[2].trim();

    if (val === '>') {
      let mlVal = '';
      i++;
      while (i < end) {
        const nl = lines[i];
        if (nl.trim() === '' || /^\s*#/.test(nl)) { i++; continue; }
        const ni = nl.search(/\S/);
        if (ni <= indent) break;
        mlVal += (mlVal ? ' ' : '') + nl.trim();
        i++;
      }
      result[key] = mlVal;
      continue;
    }

    const nextNonEmpty = findNextNonEmpty(lines, i + 1, end);
    if (nextNonEmpty < end && lines[nextNonEmpty].trim().startsWith('- ')) {
      const nextIndent = lines[nextNonEmpty].search(/\S/);
      if (nextIndent > indent) {
        result[key] = parseYamlArray(lines, i + 1, end, indent);
        i = skipBlock(lines, i + 1, end, indent);
        continue;
      }
    }

    if (val === '') {
      const ni = findNextNonEmpty(lines, i + 1, end);
      if (ni < end && lines[ni].search(/\S/) > indent) {
        result[key] = parseYamlBlock(lines, i + 1, end, indent);
        i = skipBlock(lines, i + 1, end, indent);
        continue;
      }
    }

    result[key] = unquote(val);
    i++;
  }

  return result;
}

function parseYamlArray(lines, start, end, parentIndent) {
  const result = [];
  let i = start;

  while (i < end) {
    const line = lines[i];
    if (line.trim() === '' || /^\s*#/.test(line)) { i++; continue; }

    const indent = line.search(/\S/);
    if (indent <= parentIndent) break;

    if (line.trim().startsWith('- ')) {
      const content = line.trim().slice(2).trim();
      const kvMatch = content.match(/^([\w]+):\s*(.*)/);

      if (kvMatch) {
        const obj = {};
        obj[kvMatch[1]] = kvMatch[2].trim() === '>'
          ? (() => { let v = ''; i++; while (i < end) { const l = lines[i]; if (l.trim() === '' || /^\s*#/.test(l)) { i++; continue; } if (l.search(/\S/) <= indent + 2) break; v += (v ? ' ' : '') + l.trim(); i++; } return v; })()
          : unquote(kvMatch[2]);

        if (kvMatch[2].trim() !== '>') i++;

        while (i < end) {
          const nl = lines[i];
          if (nl.trim() === '' || /^\s*#/.test(nl)) { i++; continue; }
          const ni = nl.search(/\S/);
          if (ni <= indent) break;
          if (nl.trim().startsWith('- ')) break;
          const nkv = nl.trim().match(/^([\w]+):\s*(.*)/);
          if (nkv) {
            if (nkv[2].trim() === '>') {
              let v = ''; i++;
              while (i < end) { const l = lines[i]; if (l.trim() === '' || /^\s*#/.test(l)) { i++; continue; } if (l.search(/\S/) <= ni) break; v += (v ? ' ' : '') + l.trim(); i++; }
              obj[nkv[1]] = v;
            } else {
              obj[nkv[1]] = unquote(nkv[2]);
              i++;
            }
          } else {
            i++;
          }
        }
        result.push(obj);
      } else {
        result.push(unquote(content));
        i++;
      }
    } else {
      i++;
    }
  }

  return result;
}

function findNextNonEmpty(lines, start, end) {
  for (let i = start; i < end; i++) {
    if (lines[i].trim() !== '' && !/^\s*#/.test(lines[i])) return i;
  }
  return end;
}

function skipBlock(lines, start, end, parentIndent) {
  let i = start;
  while (i < end) {
    const line = lines[i];
    if (line.trim() === '' || /^\s*#/.test(line)) { i++; continue; }
    if (line.search(/\S/) <= parentIndent) return i;
    i++;
  }
  return i;
}

export { deepMerge, parseYamlFull, findGlobalConfig, loadConfig };

// ─── Social SVG icons ───

const SOCIAL_SVGS = {
  Medium: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zm7.42 0c0 3.54-1.51 6.42-3.38 6.42S14.2 15.54 14.2 12s1.51-6.42 3.38-6.42 3.38 2.88 3.38 6.42zm2.94 0c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75c.66 0 1.19 2.58 1.19 5.75z"/></svg>',
  Facebook: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
  Threads: '<svg width="16" height="16" viewBox="0 0 878 1000" fill="currentColor"><path d="M446.7,1000h-0.3c-149.2-1-263.9-50.2-341-146.2C36.9,768.3,1.5,649.4,0.3,500.4v-0.7c1.2-149.1,36.6-267.9,105.2-353.4C182.5,50.2,297.3,1,446.4,0h0.3h0.3c114.4,0.8,210.1,30.2,284.4,87.4c69.9,53.8,119.1,130.4,146.2,227.8l-85,23.7c-46-165-162.4-249.3-346-250.6c-121.2,0.9-212.9,39-272.5,113.2C118.4,271,89.6,371.4,88.5,500c1.1,128.6,29.9,229,85.7,298.5c59.6,74.3,151.3,112.4,272.5,113.2c109.3-0.8,181.6-26.3,241.7-85.2c68.6-67.2,67.4-149.7,45.4-199.9c-12.9-29.6-36.4-54.2-68.1-72.9c-8,56.3-25.9,101.9-53.5,136.3c-36.9,45.9-89.2,71-155.4,74.6c-50.1,2.7-98.4-9.1-135.8-33.4c-44.3-28.7-70.2-72.5-73-123.5c-2.7-49.6,17-95.2,55.4-128.4c36.7-31.7,88.3-50.3,149.3-53.8c44.9-2.5,87-0.5,125.8,5.9c-5.2-30.9-15.6-55.5-31.2-73.2c-21.4-24.4-54.5-36.8-98.3-37.1c-0.4,0-0.8,0-1.2,0c-35.2,0-83,9.7-113.4,55L261.2,327c40.8-60.6,107-94,186.6-94c0.6,0,1.2,0,1.8,0c133.1,0.8,212.4,82.3,220.3,224.5c4.5,1.9,9,3.9,13.4,5.9c62.1,29.2,107.5,73.4,131.4,127.9c33.2,75.9,36.3,199.6-64.5,298.3C673.1,965,579.6,999.1,447,1000L446.7,1000L446.7,1000z M488.5,512.9c-10.1,0-20.3,0.3-30.8,0.9c-76.5,4.3-124.2,39.4-121.5,89.3c2.8,52.3,60.5,76.6,116,73.6c51-2.7,117.4-22.6,128.6-154.6C552.6,516,521.7,512.9,488.5,512.9z"/></svg>',
  YouTube: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
  GitHub: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"/></svg>',
  LinkedIn: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
  Email: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 7L2 7"/></svg>',
};

function socialLink(platform, url) {
  const svg = SOCIAL_SVGS[platform] || '';
  return `<a href="${esc(url)}" target="_blank" rel="noopener">${svg} ${esc(platform)}</a>`;
}

function esc(s) {
  if (typeof s !== 'string') return '';
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function raw(s) { return typeof s === 'string' ? s : ''; }

// ─── Markdown parser ───

function parseContent(md) {
  const lines = md.replace(/\r\n?/g, '\n').split('\n');
  const sections = [];
  const headerBlocks = [];
  const preSection = { blocks: headerBlocks };
  let current = preSection;
  let currentSub = null;
  let i = 0;
  let sectionNum = 0;
  let subNum = 0;
  const usedIds = new Set();

  // ── Branch 區段狀態 ──
  let currentBranch = null;   // 目前繼承中的分支名（主線為 null）
  let curSeg = 0;             // 區段序號，每次分支狀態變化遞增
  const branchSegments = [];  // 每個分支區段一筆（含起止錨點），供左側 git rail 渲染
  let openSeg = null;         // 目前開放中的分支區段（用於回填 endAnchorId）

  // 依標題上的 branch token 更新區段狀態。切換或結束時，回填上一區段的 endAnchorId（= 此標題錨點）。
  function enterBranch(token, anchorId, label) {
    if (token.isNone) {
      if (currentBranch !== null) {
        curSeg++;
        currentBranch = null;
        if (openSeg) { openSeg.endAnchorId = anchorId; openSeg.endKind = 'none'; openSeg = null; }
      }
    } else if (token.branch !== undefined && token.branch !== currentBranch) {
      curSeg++;
      currentBranch = token.branch;
      if (openSeg) { openSeg.endAnchorId = anchorId; openSeg.endKind = 'branch'; }
      // endKind 預設 'end'（最後未被 close 的區段 = 延伸到內容結尾）
      openSeg = { seg: curSeg, branch: token.branch, key: branchColorKey(token.branch), anchorId, endAnchorId: null, endKind: 'end', label };
      branchSegments.push(openSeg);
    }
  }

  function uniqueId(base) {
    const seed = base || 'section';
    let candidate = seed;
    let suffix = 2;
    while (usedIds.has(candidate)) {
      candidate = `${seed}-${suffix}`;
      suffix++;
    }
    usedIds.add(candidate);
    return candidate;
  }

  while (i < lines.length) {
    const line = lines[i];

    if (/^---\s*$/.test(line.trim())) { i++; continue; }

    if (/^# /.test(line)) {
      let title = line.replace(/^# /, '').trim();
      const bt = extractBranch(title);
      title = bt.title;
      // 非編號章節：標題以 emoji 開頭 → 用該 emoji 取代 1/2/3 數字序號，且不計入章節編號
      let icon = null;
      const iconMatch = title.match(/^((?:\p{Extended_Pictographic}(?:️|‍\p{Extended_Pictographic}|[\u{1F3FB}-\u{1F3FF}])*)+)\s+(.+)$/u);
      if (iconMatch) {
        icon = iconMatch[1];
        title = iconMatch[2].trim();
      } else {
        sectionNum++;
      }
      let label, h2;
      const colonMatch = title.match(/^(.+?)[：:]\s*(.+)/);
      if (colonMatch) {
        label = colonMatch[1].trim();
        h2 = colonMatch[2].trim();
      } else {
        label = title;
        h2 = title;
      }

      const id = uniqueId(generateId(title) || `section-${sectionNum || 'x'}`);
      enterBranch(bt, id, stripInlineMarkdown(label));
      current = { type: 'section', num: icon ? null : sectionNum, icon, label, h2, id, seg: curSeg, branch: currentBranch, lead: '', subs: [], blocks: [] };
      currentSub = null;
      sections.push(current);

      if (i + 1 < lines.length && /^> /.test(lines[i + 1]) && !/^> \*\*/.test(lines[i + 1])) {
        i++;
        let lead = lines[i].replace(/^> /, '');
        while (i + 1 < lines.length && /^> /.test(lines[i + 1]) && !/^> \*\*/.test(lines[i + 1])) {
          i++;
          lead += '\n' + lines[i].replace(/^> /, '');
        }
        current.lead = lead.trim();
      }
      i++; continue;
    }

    if (/^## /.test(line)) {
      let title = line.replace(/^## /, '').trim();
      const bt = extractBranch(title);
      title = bt.title;
      subNum++;
      const subId = uniqueId('sub-' + (generateId(title) || `section-${subNum}`));
      enterBranch(bt, subId, stripInlineMarkdown(title));
      currentSub = { title, id: subId, seg: curSeg, branch: currentBranch };
      if (current) {
        current.subs.push(currentSub);
        current.blocks.push({ type: 'sub-title', title, id: subId, seg: curSeg, branch: currentBranch });
      }
      i++; continue;
    }

    // ── youtube embed ──
    if (/^\[youtube/.test(line.trim())) {
      const idMatch = line.match(/id="([^"]+)"/);
      const titleMatch = line.match(/title="([^"]+)"/);
      const vid = idMatch ? idMatch[1] : '';
      let caption = titleMatch ? titleMatch[1] : '';
      const isSingleLineYoutube = /^\[youtube\b[^\]]*\]\s*$/.test(line.trim());
      // Block form only applies when the opening tag is not already a complete single-line embed.
      if (!isSingleLineYoutube) {
        i++;
        const captionLines = [];
        while (i < lines.length && !/^\[\/youtube\]/.test(lines[i].trim())) {
          if (lines[i].trim() !== '') captionLines.push(lines[i].trim());
          i++;
        }
        i++; // skip [/youtube]
        if (!caption && captionLines.length) caption = captionLines.join(' ');
      } else {
        i++;
      }
      if (current && vid) current.blocks.push({ type: 'youtube', id: vid, caption });
      continue;
    }

    // ── image-text block ──
    if (/^\[image-text/.test(line.trim())) {
      const posMatch = line.match(/position="(left|right)"/);
      const position = posMatch ? posMatch[1] : 'left';
      const widthMatch = line.match(/width="(\d+)%?"/);
      const imgWidth = widthMatch ? parseInt(widthMatch[1], 10) : 40;
      let imgSrc = '', imgAlt = '';
      const textLines = [];
      i++;
      while (i < lines.length && !/^\[\/image-text\]/.test(lines[i].trim())) {
        const imgMatch = lines[i].trim().match(/^!\[([^\]]*)\]\(([^)]+)\)/);
        if (imgMatch && !imgSrc) {
          imgAlt = imgMatch[1];
          imgSrc = imgMatch[2];
        } else if (lines[i].trim() !== '') {
          textLines.push(lines[i]);
        }
        i++;
      }
      i++; // skip [/image-text]
      if (current) current.blocks.push({ type: 'image-text', position, imgWidth, imgSrc, imgAlt, textLines });
      continue;
    }

    // ── standalone image ──
    if (/^!\[([^\]]*)\]\(([^)]+)\)/.test(line.trim()) && current) {
      const imgMatch = line.trim().match(/^!\[([^\]]*)\]\(([^)]+)\)(?:\{max-width=([^}]+)\})?/);
      current.blocks.push({ type: 'image', alt: imgMatch[1], src: imgMatch[2], maxWidth: imgMatch[3] || null });
      i++; continue;
    }

    if (isMarkdownTableHeader(line, lines[i + 1]) && current) {
      const headers = parseMarkdownTableRow(line);
      const aligns = parseMarkdownTableAlignments(lines[i + 1]);
      const rows = [];
      i += 2;
      while (i < lines.length) {
        const rowLine = lines[i];
        if (rowLine.trim() === '' || !rowLine.includes('|')) break;
        rows.push(parseMarkdownTableRow(rowLine));
        i++;
      }
      current.blocks.push({ type: 'table', headers, aligns, rows });
      continue;
    }

    if (/^### /.test(line)) {
      let title = line.replace(/^### /, '').trim();
      const bt = extractBranch(title);
      title = bt.title;
      const hasBranchToken = bt.isNone || bt.branch !== undefined;
      const emojiMatch = title.match(/^(\p{Emoji_Presentation}|\p{Extended_Pictographic})\s*(.*)/u);
      const icon = emojiMatch ? emojiMatch[1] : '';
      const cardTitle = emojiMatch ? emojiMatch[2] : title;
      let cardId;
      if (hasBranchToken) {
        // 帶 branch token 的卡片需有 id 作為 scroll-spy / 浮層跳轉錨點
        cardId = uniqueId('card-' + (generateId(title) || 'card'));
        enterBranch(bt, cardId, stripInlineMarkdown(cardTitle));
      }
      const card = { type: 'card', icon, title: cardTitle, items: [], seg: curSeg, branch: currentBranch };
      if (cardId) card.id = cardId;

      i++;
      while (i < lines.length) {
        const cl = lines[i];
        if (/^#{1,4} /.test(cl) || /^---\s*$/.test(cl.trim())) break;
        if (/^```(prompt|terminal|code)/i.test(cl) || /^\[flow\]/.test(cl) || /^\[tags\]/.test(cl) || /^\[summary\]/.test(cl) || /^\[bonus/.test(cl) || /^> /.test(cl) || /^\[image-text/.test(cl) || /^\[youtube/.test(cl) || /^\[html\]/.test(cl) || /^\[qa-session/.test(cl) || /^\[lab-session/.test(cl) || /^\[interactive/.test(cl) || /^\[survey/.test(cl) || /^\[download\b/.test(cl) || /^\[pr\b/.test(cl) || /^\[warning\b/.test(cl)) break;
        if (/^- \[x\]/.test(cl) || /^!\[/.test(cl)) break;
        if (isMarkdownTableHeader(cl, lines[i + 1])) break;

        // Blank line after content → end this card, let remaining lines parse independently
        if (cl.trim() === '' && card.items.length > 0) {
          i++;
          break;
        }

        if (/^- /.test(cl) && !/^- \[/.test(cl)) {
          card.items.push({ type: 'li', text: inlineFormat(cl.replace(/^- /, '').trim()) });
        } else if (cl.trim() !== '') {
          card.items.push({ type: 'p', text: inlineFormat(cl.trim()) });
        }
        i++;
      }
      if (current) current.blocks.push(card);
      continue;
    }

    if (/^#### /.test(line) && current) {
      const title = line.replace(/^#### /, '').trim();
      current.blocks.push({ type: 'minor-title', title });
      i++;
      continue;
    }

    if (/^```(prompt|terminal|Terminal|Prompt|code|Code)/i.test(line)) {
      const langMatch = line.match(/^```(\w+)/);
      const lang = langMatch ? langMatch[1].toLowerCase() : 'prompt';
      const labelMatch = line.match(/\[label="([^"]+)"\]/);
      const label = labelMatch ? labelMatch[1] : '';
      let body = '';
      i++;
      while (i < lines.length && lines[i].trim() !== '```') {
        body += (body ? '\n' : '') + lines[i];
        i++;
      }
      i++;
      let headerType;
      if (lang === 'terminal') {
        headerType = 'Terminal';
      } else if (lang === 'code') {
        headerType = 'Code';
      } else if (lang === 'prompt') {
        const isTerminal = /^(npm |npx |openspec |git |docker |curl |brew |apt |pip |cargo |\/init)/.test(body.trim());
        headerType = isTerminal ? 'Terminal' : 'Prompt';
      } else {
        headerType = 'Prompt';
      }
      if (current) current.blocks.push({ type: 'prompt', label, body, headerType });
      continue;
    }

    // ── raw HTML block ──
    if (/^\[html\]/.test(line.trim())) {
      let htmlContent = '';
      i++;
      while (i < lines.length && !/^\[\/html\]/.test(lines[i].trim())) {
        htmlContent += (htmlContent ? '\n' : '') + lines[i];
        i++;
      }
      i++; // skip [/html]
      if (current) current.blocks.push({ type: 'raw-html', content: htmlContent });
      continue;
    }

    if (/^\[flow\]/.test(line.trim())) {
      const steps = [];
      i++;
      while (i < lines.length && !/^\[\/flow\]/.test(lines[i].trim())) {
        const stepMatch = lines[i].trim().match(/^(?:\d+\.\s+|-\s+)(.*)/);
        if (stepMatch) {
          const parts = stepMatch[1].split(/\s[—–-]\s/);
          steps.push({ title: parts[0].trim(), desc: parts[1] ? parts[1].trim() : '' });
        }
        i++;
      }
      i++;
      if (current) current.blocks.push({ type: 'flow', steps });
      continue;
    }

    if (/^\[tags\]/.test(line.trim())) {
      const tags = [];
      i++;
      while (i < lines.length && !/^\[\/tags\]/.test(lines[i].trim())) {
        const tagMatch = lines[i].trim().match(/^-\s+\[(green|orange|purple|blue)\]\s+(.*)/);
        if (tagMatch) {
          tags.push({ color: tagMatch[1], text: tagMatch[2] });
        }
        i++;
      }
      i++;
      if (current) current.blocks.push({ type: 'tags', tags });
      continue;
    }

    if (/^\[summary\]/.test(line.trim())) {
      const items = [];
      i++;
      while (i < lines.length && !/^\[\/summary\]/.test(lines[i].trim())) {
        const sumMatch = lines[i].trim().match(/^-\s+(\S+)\s+\*\*(.+?)\*\*\s*\|\s*(.*)/);
        if (sumMatch) {
          items.push({ icon: sumMatch[1], title: sumMatch[2], desc: sumMatch[3].trim() });
        }
        i++;
      }
      i++;
      if (current) current.blocks.push({ type: 'summary', items });
      continue;
    }

    if (/^\[time\]/.test(line.trim())) {
      const items = [];
      let currentItem = null;
      i++;
      while (i < lines.length && !/^\[\/time\]/.test(lines[i].trim())) {
        const trimmed = lines[i].trim();
        const bulletField = trimmed.match(/^-\s+([\w-]+):\s*(.*)$/);
        const field = trimmed.match(/^([\w-]+):\s*(.*)$/);
        const compact = isClassTimelineLine(trimmed);

        if (bulletField) {
          currentItem = { index: items.length + 1, label: '', marker: '', date: '', weekday: '', time: '', des: '', link: null, status: '', active: false };
          assignTimeItemField(currentItem, bulletField[1], bulletField[2]);
          items.push(currentItem);
        } else if (field && currentItem) {
          assignTimeItemField(currentItem, field[1], field[2]);
        } else if (compact) {
          const parsed = parseClassTimelineLine(trimmed, items.length + 1);
          currentItem = { ...parsed, label: '', marker: '', link: null, status: '', active: false };
          items.push(currentItem);
        }
        i++;
      }
      i++;
      const visibleItems = items.filter(item => item.date || item.time || item.des);
      resolveTimelineStatus(visibleItems);
      if (current) current.blocks.push({ type: 'class-timeline', items: visibleItems });
      continue;
    }

    if (/^\[qa-session/.test(line.trim())) {
      const titleMatch = line.match(/title="([^"]+)"/);
      const title = titleMatch ? titleMatch[1] : 'Q&A 時間';
      const items = [];
      i++;
      while (i < lines.length && !/^\[\/qa-session\]/.test(lines[i].trim())) {
        const qMatch = lines[i].trim().match(/^- Q:\s*(.*)/);
        if (qMatch) {
          const q = qMatch[1].trim();
          let a = '';
          i++;
          while (i < lines.length) {
            const aMatch = lines[i].trim().match(/^A:\s*(.*)/);
            if (aMatch) { a = aMatch[1].trim(); i++; break; }
            if (/^\[\/qa-session\]/.test(lines[i].trim()) || /^- Q:/.test(lines[i].trim())) break;
            i++;
          }
          if (q) items.push({ q, a });
        } else {
          i++;
        }
      }
      i++; // skip [/qa-session]
      if (current) current.blocks.push({ type: 'qa-session', title, items });
      continue;
    }

    if (/^\[lab-session/.test(line.trim())) {
      const titleMatch = line.match(/title="([^"]+)"/);
      const title = titleMatch ? titleMatch[1] : '🛠️ 實作時間';
      const durationMatch = line.match(/duration="([^"]+)"/);
      const duration = durationMatch ? durationMatch[1] : '';
      const hintMatch = line.match(/hint="([^"]+)"/);
      const hint = hintMatch ? hintMatch[1] : '有問題歡迎提出，你的問題可能是大家的問題';
      const tasks = [];
      i++;
      while (i < lines.length && !/^\[\/lab-session\]/.test(lines[i].trim())) {
        const taskMatch = lines[i].trim().match(/^- (.*)/);
        if (taskMatch) tasks.push(taskMatch[1].trim());
        i++;
      }
      i++; // skip [/lab-session]
      if (current) current.blocks.push({ type: 'lab-session', title, duration, hint, tasks });
      continue;
    }

    if (/^\[interactive/.test(line.trim())) {
      const titleMatch = line.match(/title="([^"]+)"/);
      const title = titleMatch ? titleMatch[1] : '💬 互動環節';
      const scriptLines = [];
      i++;
      while (i < lines.length && !/^\[\/interactive\]/.test(lines[i].trim())) {
        scriptLines.push(lines[i]);
        i++;
      }
      i++; // skip [/interactive]
      while (scriptLines.length && scriptLines[0].trim() === '') scriptLines.shift();
      while (scriptLines.length && scriptLines[scriptLines.length - 1].trim() === '') scriptLines.pop();
      const script = scriptLines.join('\n');
      if (current) current.blocks.push({ type: 'interactive', title, script });
      continue;
    }

    if (/^\[warning\b/.test(line.trim())) {
      const titleMatch = line.match(/title="([^"]+)"/);
      const title = titleMatch ? titleMatch[1] : '';
      const contentLines = [];
      i++;
      while (i < lines.length && !/^\[\/warning\]/.test(lines[i].trim())) {
        contentLines.push(lines[i]);
        i++;
      }
      i++; // skip [/warning]
      const parts = [];
      const bullets = [];
      let paraLines = [];
      for (const cl of contentLines) {
        const bm = cl.trim().match(/^- (.*)/);
        if (bm) {
          if (paraLines.length) { parts.push(paraLines.join(' ').trim()); paraLines = []; }
          bullets.push(bm[1].trim());
        } else if (cl.trim() === '') {
          if (paraLines.length) { parts.push(paraLines.join(' ').trim()); paraLines = []; }
        } else {
          paraLines.push(cl.trim());
        }
      }
      if (paraLines.length) parts.push(paraLines.join(' ').trim());
      if (current) current.blocks.push({ type: 'warning', title, parts, bullets });
      continue;
    }

    if (/^\[bonus/.test(line.trim())) {
      const titleMatch = line.match(/title="([^"]+)"/);
      const title = titleMatch ? titleMatch[1] : 'Bonus';
      let content = '';
      i++;
      while (i < lines.length && !/^\[\/bonus\]/.test(lines[i].trim())) {
        content += (content ? '\n' : '') + lines[i];
        i++;
      }
      i++;
      if (current) current.blocks.push({ type: 'bonus', title, content });
      continue;
    }

    if (/^\[survey/.test(line.trim())) {
      const titleMatch = line.match(/title="([^"]+)"/);
      const title = titleMatch ? titleMatch[1] : '課程滿意度問卷';
      const urlMatch = line.match(/url="([^"]+)"/);
      const url = urlMatch ? urlMatch[1] : '';
      const hintMatch = line.match(/hint="([^"]+)"/);
      const hint = hintMatch ? hintMatch[1] : '您的意見是我們進步的動力';
      const btnMatch = line.match(/btn="([^"]+)"/);
      const btn = btnMatch ? btnMatch[1] : '填寫問卷';
      i++;
      while (i < lines.length && !/^\[\/survey\]/.test(lines[i].trim())) {
        i++;
      }
      i++; // skip [/survey]
      if (current) current.blocks.push({ type: 'survey', title, url, hint, btn });
      continue;
    }

    // ── download button（單行；指向 example/<dir> 打包出的 assets/<dir>.zip）──
    if (/^\[download\b/.test(line.trim())) {
      const dirMatch = line.match(/dir="([^"]+)"/);
      const fileMatch = line.match(/file="([^"]+)"/);
      const labelMatch = line.match(/label="([^"]+)"/);
      const descMatch = line.match(/desc="([^"]+)"/);
      // dir：example 子資料夾名（build 時打包成 assets/<dir>.zip）；file：直接指定既有檔案
      const dir = dirMatch ? dirMatch[1] : '';
      const file = fileMatch ? fileMatch[1] : (dir ? `assets/${dir}.zip` : '');
      const label = labelMatch ? labelMatch[1] : (dir || file || '下載範例檔');
      const desc = descMatch ? descMatch[1] : '';
      i++;
      if (current && file) current.blocks.push({ type: 'download', file, label, desc });
      continue;
    }

    // ── PR card（merge A → B，可附 PR 連結）──
    if (/^\[pr\b/.test(line.trim())) {
      const attr = (name) => {
        const m = line.match(new RegExp(`${name}="([^"]*)"`));
        return m ? m[1] : '';
      };
      const url = attr('url');
      let number = attr('number');
      if (!number && url) {
        const numMatch = url.match(/\/(?:pull|merge_requests|pull-requests)\/(\d+)/);
        if (numMatch) number = numMatch[1];
      }
      const status = attr('status').toLowerCase();
      i++;
      if (current) current.blocks.push({
        type: 'pr',
        from: attr('from'),
        to: attr('to'),
        title: attr('title'),
        desc: attr('desc'),
        url,
        number,
        status: ['merged', 'open', 'draft', 'closed'].includes(status) ? status : '',
      });
      continue;
    }

    if (/^> \*\*/.test(line)) {
      const titleMatch = line.match(/^> \*\*(.+?)\*\*/);
      const insightTitle = titleMatch ? titleMatch[1] : '';
      const restOfLine = line.replace(/^> \*\*.+?\*\*\s*/, '').trim();
      i++;
      const { parts, bullets, nextIdx } = parseInsightBody(lines, i, restOfLine, true);
      i = nextIdx;
      if (current) current.blocks.push({ type: 'insight', title: insightTitle, parts, bullets });
      continue;
    }

    if (/^> /.test(line) && !/^> \*\*/.test(line)) {
      const restOfLine = line.replace(/^>\s?/, '').trim();
      i++;
      const { parts, bullets, nextIdx } = parseInsightBody(lines, i, restOfLine, false);
      i = nextIdx;
      if (current) current.blocks.push({ type: 'insight', title: '', parts, bullets });
      continue;
    }

    if (/^- \[x\]/.test(line)) {
      const items = [];
      while (i < lines.length && /^- \[x\]/.test(lines[i])) {
        items.push(lines[i].replace(/^- \[x\]\s*/, '').trim());
        i++;
      }
      if (current) current.blocks.push({ type: 'checklist', items });
      continue;
    }

    if (isListItemLine(line, 0) && current) {
      const { block, nextIdx } = parseListBlock(lines, i, 0, 0);
      current.blocks.push(block);
      i = nextIdx;
      continue;
    }

    if (line.trim() !== '' && current && !/^#{1,4} /.test(line)) {
      current.blocks.push({ type: 'paragraph', text: inlineFormat(line.trim()) });
      i++; continue;
    }

    i++;
  }

  return { sections, headerBlocks, branchSegments };
}

function generateId(title) {
  const map = {
    '新專案': 'new-project', '舊專案': 'old-project', '導入測試': 'testing', '總結': 'summary',
    'OpenSpec 初始化': 'openspec-init', '從零建立專案': 'create-project', '建立專案規則': 'project-rules',
    'OpenSpec 迭代': 'openspec-iterate', '設定 Commit Skill': 'commit-skill', 'Commit Skill': 'commit-skill',
    '設定 PR Skill': 'pr-skill', 'PR Skill': 'pr-skill',
    'Git Worktree 並行開發': 'worktree', 'Worktree': 'worktree',
    'gen-test-cases': 'gen-test', 'GitHub Action 自動化': 'github-action', 'GitHub Action': 'github-action',
  };

  for (const [k, v] of Object.entries(map)) {
    if (title.includes(k)) return v;
  }

  return title
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .toLowerCase()
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

// 從標題尾端解析 `| branch:xxx` 標記（含 branch:none）。回傳剝除標記後的純標題。
// - 有 branch:xxx → { branch: 'xxx', isNone:false }
// - branch:none   → { branch: undefined, isNone:true }（結束分支、回主線）
// - 無標記        → { branch: undefined, isNone:false }（沿用繼承狀態）
function extractBranch(title) {
  const m = title.match(/\s*\|\s*branch:\s*([^\s|]+)\s*$/i);
  if (!m) return { title, branch: undefined, isNone: false };
  const cleaned = title.slice(0, m.index).trim();
  if (/^none$/i.test(m[1])) return { title: cleaned, branch: undefined, isNone: true };
  return { title: cleaned, branch: m[1], isNone: false };
}

// 將分支名（取 `/` 前第一段）映射到色票 key。
function branchColorKey(name) {
  const head = String(name).split('/')[0].toLowerCase();
  if (head === 'main' || head === 'master') return 'main';
  if (head === 'develop' || head === 'dev' || head === 'development') return 'develop';
  if (head === 'feature' || head === 'feat') return 'feature';
  if (head === 'release' || head === 'rel') return 'release';
  if (head === 'hotfix' || head === 'fix' || head === 'bugfix') return 'hotfix';
  return 'default';
}

function isMarkdownTableSeparator(line) {
  const trimmed = (line || '').trim();
  if (!trimmed.includes('|')) return false;
  const cells = trimmed.replace(/^\||\|$/g, '').split('|').map(cell => cell.trim());
  return cells.length > 0 && cells.every(cell => /^:?-{3,}:?$/.test(cell));
}

function isMarkdownTableHeader(line, nextLine) {
  return !!line && !!nextLine && line.includes('|') && isMarkdownTableSeparator(nextLine);
}

function parseMarkdownTableRow(line) {
  return line.trim().replace(/^\||\|$/g, '').split('|').map(cell => cell.trim());
}

function parseMarkdownTableAlignments(line) {
  return parseMarkdownTableRow(line).map(cell => {
    const isLeft = cell.startsWith(':');
    const isRight = cell.endsWith(':');
    if (isLeft && isRight) return 'center';
    if (isRight) return 'right';
    return 'left';
  });
}

function isClassTimelineLine(line) {
  const trimmed = (line || '').trim();
  if (!trimmed || trimmed.startsWith('|') || !trimmed.includes('|')) return false;
  const cells = trimmed.split('|').map(cell => cell.trim());
  if (cells.length < 2) return false;
  const dateOk = /^\d{1,2}\s*\/\s*\d{1,2}(?:\s*[（(][^）)]+[）)])?$/.test(cells[0]);
  const timeOk = /\d{1,2}:\d{2}\s*(?:~|-|–|—|到|至)\s*\d{1,2}:\d{2}/.test(cells[1]);
  return dateOk && timeOk;
}

function parseClassTimelineLine(line, index) {
  const cells = line.trim().split('|').map(cell => cell.trim());
  const parsedDate = parseTimelineDate(cells[0]);
  return {
    index,
    date: parsedDate.date,
    weekday: parsedDate.weekday,
    time: cells[1] || '',
    des: cells.slice(2).join(' | ').trim(),
  };
}

function assignTimeItemField(item, key, value) {
  const normalizedKey = key.toLowerCase();
  const cleanValue = value.trim();

  if (normalizedKey === 'date') {
    const parsed = parseTimelineDate(cleanValue);
    item.date = parsed.date;
    if (parsed.weekday && !item.weekday) item.weekday = parsed.weekday;
  } else if (normalizedKey === 'weekday' || normalizedKey === 'day') {
    item.weekday = cleanValue;
  } else if (normalizedKey === 'time') {
    item.time = cleanValue;
  } else if (normalizedKey === 'des' || normalizedKey === 'desc' || normalizedKey === 'description'
    || normalizedKey === 'title' || normalizedKey === 'topic') {
    item.des = cleanValue;
  } else if (normalizedKey === 'link' || normalizedKey === 'url' || normalizedKey === 'href') {
    const md = cleanValue.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (md) item.link = { text: md[1].trim(), url: md[2].trim() };
    else if (cleanValue) item.link = { text: '', url: cleanValue };
  } else if (normalizedKey === 'label') {
    item.label = cleanValue;
  } else if (normalizedKey === 'marker') {
    item.marker = cleanValue;
  } else if (normalizedKey === 'status' || normalizedKey === 'state') {
    const v = cleanValue.toLowerCase();
    if (v === 'past' || v === 'done' || v === 'completed' || v === 'finished') item.status = 'past';
    else if (v === 'current' || v === 'now' || v === 'active') item.status = 'current';
    else if (v === 'upcoming' || v === 'future' || v === 'next' || v === 'todo') item.status = 'upcoming';
  } else if (normalizedKey === 'active' || normalizedKey === 'current' || normalizedKey === 'now' || normalizedKey === 'here') {
    const v = cleanValue.toLowerCase();
    item.active = !(v === 'false' || v === 'no' || v === '0' || v === 'off');
  }
}

function resolveTimelineStatus(items) {
  if (!items || items.length === 0) return;
  const explicit = items.some(it => it.status);
  if (explicit) return;
  const activeIdx = items.findIndex(it => it.active);
  if (activeIdx < 0) return;
  items.forEach((it, idx) => {
    if (idx < activeIdx) it.status = 'past';
    else if (idx === activeIdx) it.status = 'current';
    else it.status = 'upcoming';
  });
}

function parseTimelineDate(value) {
  const dateMatch = value.match(/^(\d{1,2})\s*\/\s*(\d{1,2})(?:\s*[（(]([^）)]+)[）)])?$/);
  return {
    date: dateMatch ? `${dateMatch[1]}/${dateMatch[2]}` : value,
    weekday: dateMatch && dateMatch[3] ? dateMatch[3].trim() : '',
  };
}

function statusLabel(status) {
  if (status === 'past') return '已完成';
  if (status === 'current') return '進行中';
  if (status === 'upcoming') return '即將開始';
  return '';
}

function formatWeekdayLabel(weekday) {
  if (!weekday) return '';
  if (/^(週|周|星期|禮拜)/.test(weekday)) return weekday;
  if (/^[日一二三四五六天]$/.test(weekday)) return `週${weekday}`;
  return weekday;
}

function inlineFormat(text) {
  return text
    .replace(/!\[([^\]]*)\]\(([^)]+)\)(?:\{max-width=([^}]+)\})?/g, (_, alt, src, maxWidth) => {
      const style = maxWidth ? ` style="max-width:${maxWidth}"` : '';
      return `<img src="${src}" alt="${alt}" class="inline-image"${style}>`;
    })
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/(?<![("'=>\]])(https?:\/\/[^\s<>"'`)\]，。、；：！？「」『』（）【】]+)/g, '[$1]($1)')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
}

function inlineFormatWithBreaks(text) {
  return inlineFormat(text).replace(/\n/g, '<br>');
}

// blockquote 內 fenced code 的 header 類型判斷（沿用 prompt block 的啟發式）
function codeFenceHeaderType(lang, body) {
  const isTerminal = /^(npm |npx |pnpm |yarn |openspec |git |docker |curl |wget |brew |apt |pip |cargo |cd |ls |mkdir |rm |cat |echo |\/init)/.test(body.trim());
  if (lang === 'terminal') return 'Terminal';
  if (lang === 'code') return 'Code';
  if (lang === 'prompt') return isTerminal ? 'Terminal' : 'Prompt';
  if (lang) return 'Code';
  return isTerminal ? 'Terminal' : 'Code';
}

// 解析 blockquote 主體（連續 `>` 行）為有序 parts（para / code）與 bullets。
// firstLine：起始段落文字（title 行剩餘文字或純引言首行）。
// enableBullets：true 時 `- ` 收為 bullets（帶標題 insight）；false 維持純文字行為。
function parseInsightBody(lines, startIdx, firstLine, enableBullets) {
  const parts = [];
  const bullets = [];
  let para = firstLine || '';
  let i = startIdx;

  const flushPara = () => {
    const t = para.trim();
    if (t) parts.push({ type: 'para', html: inlineFormatWithBreaks(t) });
    para = '';
  };

  while (i < lines.length && /^>/.test(lines[i])) {
    const content = lines[i].replace(/^>\s?/, '').trim();

    const fence = content.match(/^```(\w*)/);
    if (fence) {
      flushPara();
      const lang = (fence[1] || '').toLowerCase();
      const labelMatch = content.match(/\[label="([^"]+)"\]/);
      const label = labelMatch ? labelMatch[1] : '';
      let body = '';
      i++;
      while (i < lines.length && /^>/.test(lines[i])) {
        const inner = lines[i].replace(/^>\s?/, '');
        if (inner.trim() === '```') { i++; break; }
        body += (body ? '\n' : '') + inner;
        i++;
      }
      parts.push({ type: 'code', body, headerType: codeFenceHeaderType(lang, body), label });
      continue;
    }

    if (content === '') {
      flushPara();
    } else if (enableBullets && /^- /.test(content)) {
      flushPara();
      bullets.push(inlineFormat(content.replace(/^- /, '').trim()));
    } else {
      para += (para ? '\n' : '') + content;
    }
    i++;
  }
  flushPara();
  return { parts, bullets, nextIdx: i };
}

function getListMarker(line) {
  const m = line.match(/^(\s*)(\d+\.|-)\s+(.*)$/);
  if (!m) return null;
  if (m[2] === '-' && /^\[(x|green|orange|purple|blue)\]/.test(m[3])) return null;
  return { indent: m[1].length, marker: m[2] === '-' ? 'ul' : 'ol', text: m[3] };
}

function isListItemLine(line, requiredIndent) {
  const info = getListMarker(line);
  return info !== null && info.indent === requiredIndent;
}

function parseListBlock(lines, startIdx, baseIndent, depth) {
  const firstInfo = getListMarker(lines[startIdx]);
  const ordered = firstInfo.marker === 'ol';
  const items = [];
  let i = startIdx;

  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === '') { i++; continue; }

    const info = getListMarker(line);

    if (info && info.indent === baseIndent) {
      items.push({ text: inlineFormat(info.text.trim()), children: null });
      i++;
      continue;
    }

    if (info && info.indent > baseIndent && items.length > 0) {
      if (depth >= 1) {
        items[items.length - 1].text += ' ' + inlineFormat(info.text.trim());
        i++;
        continue;
      }
      const parsed = parseListBlock(lines, i, info.indent, depth + 1);
      items[items.length - 1].children = parsed.block;
      i = parsed.nextIdx;
      continue;
    }

    if (!info && items.length > 0 && line.search(/\S/) > baseIndent) {
      items[items.length - 1].text += ' ' + inlineFormat(line.trim());
      i++;
      continue;
    }

    break;
  }

  return { block: { type: 'list', ordered, items }, nextIdx: i };
}

function stripInlineMarkdown(text) {
  return text
    .replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1');
}

// ─── HTML generators ───

function buildTocItems(sections) {
  let html = '';
  html += `<li class="toc-group" data-section="instructor">
      <a href="#instructor" class="toc-group-title">
        <span class="toc-num">\u{1F464}</span> 講師簡介
      </a>
      <ul class="toc-sub"></ul>
    </li>\n`;

  for (const sec of sections) {
    const navLabel = sec.label.replace(/[：:].*/, '').trim();
    const numDisplay = sec.icon ? sec.icon : (sec.label === '總結' ? '★' : sec.num);
    html += `    <li class="toc-group" data-section="${sec.id}">
      <a href="#${sec.id}" class="toc-group-title">
        <span class="toc-num">${numDisplay}</span> ${esc(navLabel)}
      </a>
      <ul class="toc-sub">\n`;
    for (const sub of sec.subs) {
      html += `        <li><a href="#${sub.id}">${esc(stripInlineMarkdown(sub.title))}</a></li>\n`;
    }
    html += `      </ul>
    </li>\n`;
  }
  return html;
}

// 區段起點錨點 → 區段資料。供在標題前插入真實的 branch-flag component。
let _branchStartMap = new Map();

// 在區段起點標題前插入的 branch tag（真實內容流元件，佔垂直空間、不疊加；非起點回傳空字串）。
// 點擊可複製分支名稱：data-branch 保存原始名稱（複製來源），避免複製回饋文字污染。
function branchFlag(anchorId) {
  const s = anchorId && _branchStartMap.get(anchorId);
  if (!s) return '';
  return `<span class="branch-flag branch-flag--${s.key}" data-anchor="${anchorId}" data-branch="${esc(s.branch)}" role="button" tabindex="0" title="點擊複製分支名稱">${esc(s.branch)}</span>`;
}

// 每個分支區段一個 rail 容器（CSS 以 border 畫彎出+竪線+彎入+收尾）；JS 定位連到對應的 branch-flag。
// data-anchor=區段起點標題、data-end=區段結束標題（無則延伸到內容結尾）。
function buildBranchTags(branchSegments) {
  if (!branchSegments || branchSegments.length === 0) return '';
  return branchSegments.map(n =>
    `<div class="branch-seg branch-seg--${n.key}" data-anchor="${n.anchorId}"${n.endAnchorId ? ` data-end="${n.endAnchorId}"` : ''} data-endkind="${n.endKind}" data-branch="${esc(n.branch)}"></div>`
  ).join('\n      ');
}

function buildInstructor(cfg) {
  const inst = cfg.instructor || {};
  const placeholderHtml = '<div class="instructor-avatar-placeholder">\u{1F464}</div>';
  const onerrorHtml = placeholderHtml.replace(/"/g, '&quot;').replace(/'/g, "\\'");
  const avatar = inst.avatar
    ? `<img class="instructor-avatar" src="${esc(inst.avatar)}" alt="${esc(inst.name)}" onerror="this.outerHTML='${onerrorHtml}';">`
    : placeholderHtml;

  const statsHtml = (inst.stats || []).map(s => {
    const label = s.value
      ? `${raw(s.icon)} ${esc(s.text)} <strong>${esc(s.value)}</strong> ${esc(s.unit)}`
      : inlineFormat(s.text || '');
    return `<a href="${esc(s.url)}" target="_blank" rel="noopener">${label}</a>`;
  }).join('\n          ');

  const socialsHtml = (inst.socials || []).map(s =>
    `          ${socialLink(s.platform, s.url)}`
  ).join('\n');

  return `<section class="section">
  <div class="reveal">
    <span class="section-label" id="instructor"><span class="num">\u{1F464}</span> 講師簡介</span>
    <h2>關於講師</h2>
  </div>
  <div class="reveal">
    <div class="instructor">
      ${avatar}
      <div class="instructor-info">
        <h3>${esc(inst.name)}</h3>
        <div class="tagline">${esc(inst.tagline)}</div>
        <p>${esc(inst.bio).replace(/&lt;br\s*\/?&gt;/gi, '<br>')}</p>
        <div class="instructor-stats">
          ${statsHtml}
        </div>
        <div class="social-links">
${socialsHtml}
        </div>
      </div>
    </div>
  </div>
</section>`;
}

function buildQuote(quoteObj) {
  if (!quoteObj || !quoteObj.text) return '';
  const authorHtml = quoteObj.author
    ? `\n    <div class="quote-author">— ${esc(quoteObj.author)}</div>` : '';
  return `<section class="quote-page">
  <div class="reveal">
    <div class="quote-mark">\u201C</div>
    <blockquote>${raw(quoteObj.text)}</blockquote>${authorHtml}
    <div class="quote-line"></div>
  </div>
</section>`;
}

// Collect all blocks under a ### into a group (until next ### / sub-title / end)
function groupBlocks(blocks) {
  const result = [];
  let i = 0;
  while (i < blocks.length) {
    const b = blocks[i];
    if (b.type === 'card') {
      const group = { type: 'group', icon: b.icon, title: b.title, id: b.id, seg: b.seg, children: [] };
      if (b.items.length > 0) {
        group.children.push({ type: 'card-items', items: b.items });
      }
      i++;
      while (i < blocks.length) {
        const nb = blocks[i];
        if (nb.type === 'card' || nb.type === 'sub-title') break;
        group.children.push(nb);
        i++;
      }
      result.push(group);
    } else {
      result.push(b);
      i++;
    }
  }
  return result;
}

function renderListBlock(block, depth) {
  const tag = block.ordered ? 'ol' : 'ul';
  const cls = `loose-list${block.ordered ? ' ordered' : ''}${depth > 0 ? ' nested' : ''}`;
  const pad = '      '.padEnd(6 + depth * 2);
  let s = `<${tag} class="${cls}">\n`;
  for (const item of block.items) {
    s += `${pad}<li>${item.text}`;
    if (item.children && item.children.items && item.children.items.length) {
      s += `\n${pad}  ${renderListBlock(item.children, depth + 1)}\n${pad}`;
    }
    s += `</li>\n`;
  }
  s += `${pad.slice(2)}</${tag}>`;
  return s;
}

function renderPromptBlock(block) {
  return `<div class="prompt-block">
      <div class="prompt-header">
        <div class="dots"><span></span><span></span><span></span></div>
        ${block.headerType}
        <span class="label">${esc(block.label || '')}</span>
        <button class="copy-btn" aria-label="複製" onclick="copyPrompt(this)">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
        </button>
      </div>
      <div class="prompt-body">${esc(block.body)}</div>
    </div>`;
}

// Returns inner HTML for a block (no reveal wrapper) — used for both top-level and group children
function renderBlockBody(block) {
  switch (block.type) {
    case 'sub-title':
      return branchFlag(block.id) + `<div class="sub-title" id="${block.id}" data-seg="${block.seg}"><span class="bar"></span>${inlineFormat(block.title)}</div>`;

    case 'minor-title':
      return `<h4 class="minor-title">${inlineFormat(block.title)}</h4>`;

    case 'card-items': {
      let s = '';
      let inList = false;
      for (const item of block.items) {
        if (item.type === 'li') {
          if (!inList) { s += `<ul>\n`; inList = true; }
          s += `  <li>${item.text}</li>\n`;
        } else {
          if (inList) { s += `</ul>\n`; inList = false; }
          s += `<p>${item.text}</p>\n`;
        }
      }
      if (inList) s += `</ul>`;
      return s.trimEnd();
    }

    case 'group': {
      const childrenHtml = block.children
        .map(c => `        ${renderBlockBody(c)}`)
        .join('\n');
      const groupAttrs = `${block.id ? ` id="${block.id}"` : ''}${block.seg != null ? ` data-seg="${block.seg}"` : ''}`;
      return branchFlag(block.id) + `<div class="group-block"${groupAttrs}>
      <div class="group-header">${block.icon ? `<span class="icon">${block.icon}</span> ` : ''}${inlineFormat(block.title)}</div>
      <div class="group-body">
${childrenHtml}
      </div>
    </div>`;
    }

    case 'prompt':
      return renderPromptBlock(block);

    case 'flow': {
      let s = `<div class="flow">\n`;
      block.steps.forEach((step, idx) => {
        s += `      <div class="flow-step">
        <div class="step-num">${idx + 1}</div>
        <div class="step-content">
          <div class="step-title">${inlineFormat(step.title)}</div>
          <div class="step-desc">${inlineFormat(step.desc)}</div>
        </div>
      </div>\n`;
      });
      s += `    </div>`;
      return s;
    }

    case 'tags': {
      let s = `<div class="tags">\n`;
      for (const t of block.tags) {
        s += `      <span class="tag ${t.color}">${esc(t.text)}</span>\n`;
      }
      s += `    </div>`;
      return s;
    }

    case 'insight': {
      let s = `<div class="insight">\n`;
      if (block.title) s += `      <div class="insight-title">${inlineFormat(block.title)}</div>\n`;
      let pIdx = 0;
      for (const part of (block.parts || [])) {
        if (part.type === 'code') {
          s += `      ${renderPromptBlock(part)}\n`;
        } else {
          s += `      <p${pIdx > 0 ? ' style="margin-top:.5rem"' : ''}>${part.html}</p>\n`;
          pIdx++;
        }
      }
      if (block.bullets && block.bullets.length) {
        s += `      <ul>\n`;
        for (const b of block.bullets) s += `        <li>${b}</li>\n`;
        s += `      </ul>\n`;
      }
      s += `    </div>`;
      return s;
    }

    case 'warning': {
      let s = `<div class="warning">\n`;
      if (block.title) s += `      <div class="warning-title">⚠️ ${inlineFormat(block.title)}</div>\n`;
      let pIdx = 0;
      for (const part of (block.parts || [])) {
        s += `      <p${pIdx > 0 ? ' style="margin-top:.5rem"' : ''}>${inlineFormat(part)}</p>\n`;
        pIdx++;
      }
      if (block.bullets && block.bullets.length) {
        s += `      <ul>\n`;
        for (const b of block.bullets) s += `        <li>${inlineFormat(b)}</li>\n`;
        s += `      </ul>\n`;
      }
      s += `    </div>`;
      return s;
    }

    case 'checklist': {
      let s = `<ul class="checklist">\n`;
      for (const item of block.items) s += `      <li>${inlineFormat(item)}</li>\n`;
      s += `    </ul>`;
      return s;
    }

    case 'summary': {
      let s = `<div class="summary-grid">\n`;
      for (const item of block.items) {
        s += `      <div class="summary-card">
        <div class="sc-icon">${item.icon}</div>
        <h4>${esc(item.title)}</h4>
        <p>${inlineFormat(item.desc)}</p>
      </div>\n`;
      }
      s += `    </div>`;
      return s;
    }

    case 'table': {
      let s = `<div class="table-wrap">\n      <table class="content-table">\n        <thead>\n          <tr>\n`;
      block.headers.forEach((header, idx) => {
        s += `            <th class="align-${block.aligns[idx] || 'left'}">${inlineFormat(header)}</th>\n`;
      });
      s += `          </tr>\n        </thead>\n        <tbody>\n`;
      block.rows.forEach((row) => {
        s += `          <tr>\n`;
        block.headers.forEach((_, idx) => {
          s += `            <td class="align-${block.aligns[idx] || 'left'}">${inlineFormat(row[idx] || '')}</td>\n`;
        });
        s += `          </tr>\n`;
      });
      s += `        </tbody>\n      </table>\n    </div>`;
      return s;
    }

    case 'list': {
      return renderListBlock(block, 0);
    }

    case 'class-timeline': {
      const hasStatus = block.items.some(it => it.status);
      let s = `<div class="class-timeline${hasStatus ? ' class-timeline--has-status' : ''}">\n`;
      block.items.forEach((item) => {
        const weekday = formatWeekdayLabel(item.weekday);
        const status = item.status || '';
        const itemClass = `class-timeline__item${status ? ` is-${status}` : ''}`;
        const markerDisplay = status === 'past' && !item.marker
          ? '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'
          : esc(String(item.marker || item.index));
        const label = item.label || `第 ${item.index} 堂`;
        s += `      <div class="${itemClass}"${status ? ` data-status="${status}"` : ''}>
        <div class="class-timeline__marker">${markerDisplay}</div>
        <div class="class-timeline__card">
          ${status === 'current' ? `<span class="class-timeline__pin" aria-label="目前進度">You are here</span>` : ''}
          <div class="class-timeline__meta">
            ${label ? `<span class="class-timeline__label">${esc(label)}</span>` : ''}
            ${item.date ? `<span class="class-timeline__date">${esc(item.date)}</span>` : ''}
            ${weekday ? `<span class="class-timeline__weekday">${esc(weekday)}</span>` : ''}
            ${status ? `<span class="class-timeline__status-tag is-${status}">${esc(statusLabel(status))}</span>` : ''}
          </div>
          ${item.time ? `<div class="class-timeline__time">${esc(item.time)}</div>` : ''}
          ${item.des ? `<div class="class-timeline__des">${inlineFormat(item.des)}</div>` : ''}
          ${item.link ? `<a class="class-timeline__link" href="${esc(item.link.url)}" target="_blank" rel="noopener">${esc(item.link.text || '課程連結')}<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 17L17 7M9 7h8v8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></a>` : ''}
        </div>
      </div>\n`;
      });
      s += `    </div>`;
      return s;
    }

    case 'bonus':
      return `<button class="bonus-btn" data-bonus-title="${esc(block.title)}" data-bonus-content="${esc(block.content)}">
      ${esc(block.title)}
    </button>`;

    case 'youtube':
      return `<div class="youtube-embed">
      <div class="youtube-wrapper" data-id="${esc(block.id)}">
        <iframe src="https://www.youtube.com/embed/${esc(block.id)}" title="${esc(block.caption || 'YouTube video')}" frameborder="0" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe>
        <div class="youtube-local-notice">
          <p>本機直接開啟 HTML 時，YouTube 可能因缺少 HTTP referrer 而拒絕播放。請改用本機伺服器預覽，或直接前往 <a href="https://www.youtube.com/watch?v=${esc(block.id)}" target="_blank" rel="noopener">YouTube 觀看影片</a>。</p>
        </div>
      </div>
      ${block.caption ? `<p class="youtube-caption">${inlineFormat(block.caption)}</p>` : ''}
    </div>`;

    case 'image': {
      const maxWidthStyle = block.maxWidth ? ` style="max-width:${esc(block.maxWidth)};margin-inline:auto"` : '';
      return `<figure class="content-image"${maxWidthStyle}>
      <img src="${esc(block.src)}" alt="${esc(block.alt)}" loading="lazy">
      ${block.alt ? `<figcaption>${esc(block.alt)}</figcaption>` : ''}
    </figure>`;
    }

    case 'image-text': {
      const imgPos = block.position === 'right' ? 'image-text--img-right' : '';
      const widthStyle = block.imgWidth !== 40 ? ` style="--img-width:${block.imgWidth}%"` : '';
      let bodyHtml = '';
      for (const tl of block.textLines) {
        if (/^- /.test(tl)) {
          bodyHtml += `<li>${inlineFormat(tl.replace(/^- /, '').trim())}</li>\n`;
        } else {
          bodyHtml += `<p>${inlineFormat(tl.trim())}</p>\n`;
        }
      }
      bodyHtml = bodyHtml.replace(/((?:<li>.*<\/li>\n)+)/g, '<ul>\n$1</ul>\n');
      return `<div class="image-text ${imgPos}"${widthStyle}>
      <div class="image-text__img">
        <img src="${esc(block.imgSrc)}" alt="${esc(block.imgAlt)}" loading="lazy">
      </div>
      <div class="image-text__body">
        ${bodyHtml.trim()}
      </div>
    </div>`;
    }

    case 'raw-html': {
      const srcdoc = block.content
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;');
      const onloadHandler = `(function(f){var sync=function(){try{var d=f.contentDocument;if(!d||!d.body)return;var h=Math.ceil(d.body.getBoundingClientRect().height);if(h)f.style.height=h+'px';}catch(e){}};sync();try{var d=f.contentDocument;if(d&&'ResizeObserver' in window){var ro=new ResizeObserver(sync);ro.observe(d.documentElement);if(d.body)ro.observe(d.body);}if(f.contentWindow){f.contentWindow.addEventListener('resize',sync);}window.addEventListener('resize',sync);if(d&&d.fonts&&d.fonts.ready)d.fonts.ready.then(sync);}catch(e){}})(this)`;
      return `<iframe class="raw-html-frame" srcdoc="${srcdoc}" frameborder="0" scrolling="no" style="width:100%;border:none;overflow:hidden" onload="${onloadHandler.replace(/"/g, '&quot;')}"></iframe>`;
    }

    case 'qa-session': {
      let listHtml = '';
      if (block.items && block.items.length > 0) {
        listHtml = `<div class="qa-list">\n`;
        block.items.forEach((item) => {
          listHtml += `      <div class="qa-item">
        <button class="qa-question" aria-expanded="false" onclick="toggleQA(this)">
          <span class="qa-badge qa-badge--q">Q</span>
          <span class="qa-q-text">${inlineFormat(item.q)}</span>
          <svg class="qa-chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </button>
        <div class="qa-answer">
          <div class="qa-answer-inner">
            <span class="qa-badge qa-badge--a">A</span>
            <div class="qa-a-text">${inlineFormat(item.a)}</div>
          </div>
        </div>
      </div>\n`;
        });
        listHtml += `    </div>`;
      }
      return `<div class="qa-session">
    <div class="qa-session__deco" aria-hidden="true">?</div>
    <div class="qa-session__inner">
      <h3 class="qa-session__title">${esc(block.title)}</h3>
      <p class="qa-session__hint">歡迎提問，一起深入探討</p>
    </div>
    ${listHtml}
  </div>`;
    }

    case 'lab-session': {
      let taskHtml = '';
      if (block.tasks && block.tasks.length > 0) {
        taskHtml = `<div class="lab-task-list">\n`;
        block.tasks.forEach((task, idx) => {
          taskHtml += `      <div class="lab-task-item">
        <span class="lab-task-num">${idx + 1}</span>
        <span class="lab-task-text">${inlineFormat(task)}</span>
      </div>\n`;
        });
        taskHtml += `    </div>`;
      }
      const durationHtml = block.duration
        ? `<div class="lab-session__duration">⏱ ${esc(block.duration)}</div>`
        : '';
      return `<div class="lab-session">
    <div class="lab-session__deco" aria-hidden="true">⚙</div>
    <div class="lab-session__inner">
      <h3 class="lab-session__title">${esc(block.title)}</h3>
      ${block.hint ? `<p class="lab-session__hint">${esc(block.hint)}</p>` : ''}
      ${durationHtml}
    </div>
    ${taskHtml}
  </div>`;
    }

    case 'interactive': {
      const scriptHtml = block.script
        ? `<div class="interactive-script">
        <div class="interactive-script__mark" aria-hidden="true">"</div>
        <div class="interactive-script__body">${inlineFormatWithBreaks(block.script)}</div>
      </div>`
        : '';
      return `<div class="interactive-session">
    <div class="interactive-session__deco" aria-hidden="true">💬</div>
    <div class="interactive-session__inner">
      <h3 class="interactive-session__title">${esc(block.title)}</h3>
    </div>
    ${scriptHtml}
  </div>`;
    }

    case 'survey': {
      const linkHtml = block.url
        ? `<a class="survey-btn" href="${esc(block.url)}" target="_blank" rel="noopener">${esc(block.btn)}</a>`
        : '';
      return `<div class="survey-session">
    <div class="survey-session__deco" aria-hidden="true">★</div>
    <div class="survey-session__inner">
      <h3 class="survey-session__title">${esc(block.title)}</h3>
      <p class="survey-session__hint">${esc(block.hint)}</p>
      ${linkHtml}
    </div>
  </div>`;
    }

    case 'download': {
      const href = esc(block.file);
      return `<a class="download-card" href="${href}" download>
    <span class="download-card__icon" aria-hidden="true">⬇</span>
    <span class="download-card__body">
      <span class="download-card__label">${inlineFormat(block.label)}</span>
      ${block.desc ? `<span class="download-card__desc">${inlineFormat(block.desc)}</span>` : ''}
    </span>
    <span class="download-card__ext">ZIP</span>
  </a>`;
    }

    case 'pr': {
      const STATUS = {
        merged: { label: 'Merged', icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M5.45 5.154A4.25 4.25 0 0 0 9.25 7.5h1.378a2.251 2.251 0 1 1 0 1.5H9.25A5.734 5.734 0 0 1 5 7.123v3.505a2.251 2.251 0 1 1-1.5 0V5.372a2.25 2.25 0 1 1 1.95-.218ZM4.25 13.5a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm8.5-4.5a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5ZM5 3.25a.75.75 0 1 0 0 .005V3.25Z"/></svg>' },
        open: { label: 'Open', icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"/></svg>' },
      };
      STATUS.draft = { label: 'Draft', icon: STATUS.open.icon };
      STATUS.closed = { label: 'Closed', icon: STATUS.open.icon };
      const st = STATUS[block.status] || STATUS.merged;
      const statusHtml = block.status ? `<span class="pr-status">${st.label}</span>` : '';
      const titleHtml = block.title ? inlineFormat(block.title) : `${esc(block.from)} → ${esc(block.to)}`;
      const numberHtml = block.number ? `<span class="pr-card__number">#${esc(block.number)}</span>` : '';
      const chip = (name) => `<span class="pr-chip pr-chip--${branchColorKey(name)}">${esc(name)}</span>`;
      const arrow = '<svg class="pr-card__arrow" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M8.22 2.97a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L11.19 8.5H3.75a.75.75 0 0 1 0-1.5h7.44L8.22 4.03a.75.75 0 0 1 0-1.06Z"/></svg>';
      const descHtml = block.desc ? `\n        <span class="pr-card__desc">${inlineFormat(block.desc)}</span>` : '';
      const extHtml = block.url
        ? '\n        <svg class="pr-card__ext" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"/></svg>'
        : '';
      const tag = block.url ? 'a' : 'div';
      const linkAttrs = block.url ? ` href="${esc(block.url)}" target="_blank" rel="noopener"` : '';
      const statusClass = block.status ? ` pr-card--${block.status}` : '';
      const metaHtml = (statusHtml || extHtml)
        ? `\n      <span class="pr-card__meta">
        ${statusHtml}${extHtml}
      </span>`
        : '';
      return `<${tag} class="pr-card${statusClass}"${linkAttrs}>
      <span class="pr-card__icon" aria-hidden="true">${st.icon}</span>
      <span class="pr-card__main">
        <span class="pr-card__title">${titleHtml}${numberHtml}</span>
        <span class="pr-card__route">${chip(block.from)}${arrow}${chip(block.to)}</span>${descHtml}
      </span>${metaHtml}
    </${tag}>`;
    }

    case 'paragraph':
      return `<p class="loose-text">${block.text}</p>`;

    default:
      return '';
  }
}

function buildContentSections(sections, headerBlocks = []) {
  let html = '';

  if (headerBlocks && headerBlocks.length > 0) {
    const grouped = groupBlocks(headerBlocks);
    if (grouped.length > 0) {
      html += `\n<section class="section section--header">\n`;
      for (const block of grouped) {
        const inner = renderBlockBody(block);
        if (!inner) continue;
        html += `  <div class="reveal">\n    ${inner}\n  </div>\n`;
      }
      html += `</section>\n`;
    }
  }

  for (const sec of sections) {
    // Split blocks into segments at qa/lab boundaries to preserve their position in output
    const segments = [];
    let buf = [];
    for (const b of sec.blocks) {
      if (b.type === 'qa-session' || b.type === 'lab-session' || b.type === 'survey' || b.type === 'interactive') {
        segments.push({ regular: buf, special: b });
        buf = [];
      } else {
        buf.push(b);
      }
    }
    if (buf.length > 0 || segments.length === 0) segments.push({ regular: buf, special: null });

    const hasAnyRegular = segments.some(s => s.regular.length > 0);
    let headerDone = false;
    let specialIdx = 0;

    for (const seg of segments) {
      const grouped = groupBlocks(seg.regular);

      if (grouped.length > 0) {
        html += `\n<hr class="divider">
<section class="section">`;
        if (!headerDone) {
          html += `
  <div class="reveal">
    ${branchFlag(sec.id)}
    <span class="section-label" id="${sec.id}" data-seg="${sec.seg}"><span class="num">${sec.icon ? sec.icon : (sec.label === '總結' ? '★' : sec.num)}</span> ${esc(sec.label.replace(/[：:].*/, '').trim())}</span>
    <h2>${esc(sec.h2)}</h2>
    ${sec.lead ? `<p class="lead">${inlineFormatWithBreaks(sec.lead)}</p>` : ''}
  </div>\n`;
          headerDone = true;
        }

        for (const block of grouped) {
          const inner = renderBlockBody(block);
          if (!inner) continue;
          const extraClass = block.type === 'bonus' ? ' bonus-btn-wrap' : '';
          html += `\n  <div class="reveal${extraClass}">\n    ${inner}\n  </div>\n`;
        }
        html += `</section>\n`;
      }

      if (seg.special) {
        specialIdx++;
        const isLab = seg.special.type === 'lab-session';
        const isSurvey = seg.special.type === 'survey';
        const isInteractive = seg.special.type === 'interactive';
        const pageClass = isLab
          ? 'lab-page'
          : isSurvey
            ? 'survey-page'
            : isInteractive
              ? 'interactive-page'
              : 'qa-page';
        const suffix = isLab
          ? 'lab'
          : isSurvey
            ? 'survey'
            : isInteractive
              ? 'interactive'
              : 'qa';
        const qaId = hasAnyRegular
          ? `${sec.id}-${suffix}${specialIdx > 1 ? `-${specialIdx}` : ''}`
          : sec.id;
        html += `\n<hr class="divider">
<section class="${pageClass}" id="${qaId}">
  ${renderBlockBody(seg.special)}
</section>\n`;
      }
    }
  }

  return html;
}

function buildFooterSocials(cfg) {
  if (!cfg.footer?.show_socials) return '';
  const socials = cfg.instructor?.socials || [];
  if (!socials.length) return '';

  let html = `<p style="font-size:.9rem;color:var(--text);margin-bottom:1rem">${esc(cfg.footer.cta || '')}</p>
  <div class="social-links" style="justify-content:center;margin-bottom:1.5rem">\n`;
  for (const s of socials) {
    html += `    ${socialLink(s.platform, s.url)}\n`;
  }
  html += `  </div>`;
  return html;
}

// ─── Config loading with layering ───

function findGlobalConfig(courseDir) {
  let dir = dirname(courseDir);
  for (let i = 0; i < 4; i++) {
    const candidate = join(dir, 'config/global.yaml');
    if (existsSync(candidate)) return candidate;
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

function loadConfig(courseDir) {
  let cfg = {};
  let globalRoot = dirname(courseDir);

  const globalConfig = findGlobalConfig(courseDir);
  if (globalConfig) {
    const globalRaw = readFileSync(globalConfig, 'utf-8');
    cfg = parseYamlFull(globalRaw);
    globalRoot = dirname(dirname(globalConfig)); // dir containing config/
    console.log(`   Global config: ${globalConfig}`);
  }

  const courseConfig = join(courseDir, 'config.yaml');
  if (existsSync(courseConfig)) {
    const courseRaw = readFileSync(courseConfig, 'utf-8');
    const courseCfg = parseYamlFull(courseRaw);
    cfg = deepMerge(cfg, courseCfg);
    console.log(`   Course config: ${courseConfig}`);
  } else {
    console.log(`   Course config: (none, using global only)`);
  }

  return { cfg, globalRoot };
}

// ─── Embed local images as base64 data URIs ───

function embedLocalImages(html, courseDir) {
  return html.replace(/<img\s([^>]*?)src="([^"]+)"([^>]*?)>/g, (match, pre, src, post) => {
    if (src.startsWith('data:')) return match;
    if (/^https?:\/\//.test(src)) return match;
    const absPath = resolve(courseDir, src);
    if (!existsSync(absPath)) {
      console.warn(`   ⚠️  Image not found, skipping embed: ${absPath}`);
      return match;
    }
    const ext = absPath.split('.').pop().toLowerCase();
    const mimeMap = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp' };
    const mime = mimeMap[ext] || `image/${ext}`;
    const b64 = readFileSync(absPath).toString('base64');
    return `<img ${pre}src="data:${mime};base64,${b64}"${post}>`;
  });
}

// ─── Example folders → downloadable zips ───
// 將 <course-dir>/example/ 下的每個子資料夾，個別打包成 <course-dir>/assets/<name>.zip。
// 不依賴系統 zip 指令，改用 Node 內建 zlib 自行輸出 ZIP，刻意做到「Mac 與 Windows 都能直接解壓」：
//   • 設定 UTF-8 檔名旗標（general purpose bit 11）→ 中文檔名在 Windows 不會變亂碼
//   • 只收一般檔案、略過 dotfiles → 不會夾帶 .DS_Store / __MACOSX 等系統垃圾
//   • 壓縮內容帶一層同名資料夾（解壓後得到 <name>/...），對使用者最直覺
// 因為不靠外部工具，連沒裝 zip 的 build 環境（含 Windows）也能正常產生。

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRC32_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function dosDateTime(date) {
  const d = (date instanceof Date && !isNaN(date)) ? date : new Date(1980, 0, 1);
  const year = Math.max(1980, d.getFullYear());
  const time = ((d.getHours() & 0x1F) << 11) | ((d.getMinutes() & 0x3F) << 5) | ((d.getSeconds() >> 1) & 0x1F);
  const day = (((year - 1980) & 0x7F) << 9) | (((d.getMonth() + 1) & 0x0F) << 5) | (d.getDate() & 0x1F);
  return { time: time & 0xFFFF, date: day & 0xFFFF };
}

// entries: [{ name(string, 用 / 分隔), data(Buffer), mtime(Date) }]
function buildZip(entries) {
  const FLAG_UTF8 = 0x0800; // bit 11：檔名為 UTF-8，跨平台正確顯示中文
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const e of entries) {
    const nameBuf = Buffer.from(e.name, 'utf8');
    const crc = crc32(e.data);
    const deflated = deflateRawSync(e.data, { level: 9 });
    const useDeflate = deflated.length < e.data.length;
    const method = useDeflate ? 8 : 0;
    const body = useDeflate ? deflated : e.data;
    const { time, date } = dosDateTime(e.mtime);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(FLAG_UTF8, 6);
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(body.length, 18);
    local.writeUInt32LE(e.data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);
    localParts.push(local, nameBuf, body);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(FLAG_UTF8, 8);
    central.writeUInt16LE(method, 10);
    central.writeUInt16LE(time, 12);
    central.writeUInt16LE(date, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(body.length, 20);
    central.writeUInt32LE(e.data.length, 24);
    central.writeUInt16LE(nameBuf.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centralParts.push(central, nameBuf);

    offset += local.length + nameBuf.length + body.length;
  }

  const localBuf = Buffer.concat(localParts);
  const centralBuf = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralBuf.length, 12);
  end.writeUInt32LE(localBuf.length, 16);
  return Buffer.concat([localBuf, centralBuf, end]);
}

function collectExampleFiles(absDir, prefix, out) {
  for (const d of readdirSync(absDir, { withFileTypes: true })) {
    if (d.name.startsWith('.')) continue; // 略過 .DS_Store 等 dotfiles
    const abs = join(absDir, d.name);
    const rel = `${prefix}/${d.name}`;
    if (d.isDirectory()) {
      collectExampleFiles(abs, rel, out);
    } else if (d.isFile()) {
      out.push({ name: rel, data: readFileSync(abs), mtime: statSync(abs).mtime });
    }
  }
}

function packageExamples(courseDir) {
  const exampleDir = join(courseDir, 'example');
  if (!existsSync(exampleDir) || !statSync(exampleDir).isDirectory()) return;

  const dirs = readdirSync(exampleDir, { withFileTypes: true })
    .filter(d => d.isDirectory() && !d.name.startsWith('.'));
  if (!dirs.length) return;

  const assetsDir = join(courseDir, 'assets');
  if (!existsSync(assetsDir)) mkdirSync(assetsDir, { recursive: true });

  for (const d of dirs) {
    const entries = [];
    collectExampleFiles(join(exampleDir, d.name), d.name, entries);
    if (!entries.length) continue;
    entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0)); // 穩定輸出
    const zipPath = join(assetsDir, `${d.name}.zip`);
    try {
      writeFileSync(zipPath, buildZip(entries));
      const kb = Math.max(1, Math.round(statSync(zipPath).size / 1024));
      console.log(`   📦 example/${d.name} → assets/${d.name}.zip (${entries.length} 檔, ${kb} KB)`);
    } catch (err) {
      console.warn(`   ⚠️  無法打包 example/${d.name}：${err.message}`);
    }
  }
}

// ─── Main build ───

function build(courseDir) {
  const contentPath = join(courseDir, 'content.md');
  const outputPath = join(courseDir, 'index.html');

  if (!existsSync(contentPath)) {
    console.error(`❌ Content file not found: ${contentPath}`);
    process.exit(1);
  }

  console.log(`\n🔨 Building: ${courseDir}`);

  const { cfg, globalRoot } = loadConfig(courseDir);

  if (cfg.instructor?.avatar) {
    let absAvatar = resolve(globalRoot, cfg.instructor.avatar);
    if (!existsSync(absAvatar)) {
      for (const ext of ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg']) {
        const candidate = absAvatar + '.' + ext;
        if (existsSync(candidate)) { absAvatar = candidate; break; }
      }
    }
    if (existsSync(absAvatar)) {
      const ext = absAvatar.split('.').pop().toLowerCase();
      const mimeMap = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp' };
      const mime = mimeMap[ext] || `image/${ext}`;
      const b64 = readFileSync(absAvatar).toString('base64');
      cfg.instructor.avatar = `data:${mime};base64,${b64}`;
    } else {
      cfg.instructor.avatar = relative(courseDir, absAvatar);
    }
  }

  const contentRaw = readFileSync(contentPath, 'utf-8').replace(
    /^\[html\s+src="([^"]+)"\]\s*$/gm,
    (_, src) => {
      const absPath = resolve(courseDir, src);
      if (!existsSync(absPath)) {
        console.warn(`⚠️  HTML file not found: ${absPath}`);
        return '';
      }
      return `[html]\n${readFileSync(absPath, 'utf-8')}\n[/html]`;
    }
  );
  const templateRaw = readFileSync(BASE_HTML, 'utf-8');

  const { sections, headerBlocks, branchSegments } = parseContent(contentRaw);
  _branchStartMap = new Map(branchSegments.map(s => [s.anchorId, s]));

  const navSource = cfg.nav && cfg.nav.length
    ? cfg.nav
    : sections.map(sec => ({
      text: sec.label.replace(/[：:].*/, '').trim(),
      href: `#${sec.id}`,
    }));
  const navItems = navSource.map((n, i) =>
    `<a href="${esc(n.href)}">${esc(n.text)}</a>`
  ).join('\n    ');

  const sectionIds = ['instructor', ...sections.map(s => s.id)];
  const allAnchorIds = ['instructor'];
  for (const sec of sections) {
    allAnchorIds.push(sec.id);
    // 依文件順序收集子章節與帶 branch 的卡片錨點（順序需與捲動順序一致，scroll-spy 才能正確定位）
    for (const b of sec.blocks) {
      if ((b.type === 'sub-title' || b.type === 'card') && b.id) allAnchorIds.push(b.id);
    }
  }

  const instructorName = cfg.instructor?.name || '';
  const heroAuthor = `${instructorName} — ${cfg.instructor?.tagline || ''}`;
  const sidebarBrand = (cfg.page?.title || '').replace(/\s*[—–-]\s*/, '<br>');

  let html = templateRaw;
  html = html.replace(/<!--[\s\S]*?-->\n?/g, '');

  // Auto-detect GitHub Pages URL as fallback for SEO fields
  const ghPagesBase = detectGitHubPagesBase(globalRoot);
  const coursePath = relative(globalRoot, courseDir);
  const autoUrl = ghPagesBase ? `${ghPagesBase}/${coursePath}/` : '';
  const autoImage = ghPagesBase ? `${ghPagesBase}/${coursePath}/assets/og-image.jpg` : '';

  const og = {
    title: cfg.seo?.title || cfg.page?.title || '',
    description: cfg.seo?.description || cfg.page?.subtitle || '',
    image: cfg.seo?.image || cfg.seo?.default_image || autoImage,
    url: cfg.seo?.url || autoUrl,
    type: cfg.seo?.type || 'article',
    siteName: cfg.seo?.site_name || cfg.instructor?.name || '',
  };

  if (!cfg.seo?.image && autoImage) {
    console.log(`   SEO image (auto): ${autoImage}`);
  }
  if (!cfg.seo?.url && autoUrl) {
    console.log(`   SEO url   (auto): ${autoUrl}`);
  }

  const replacements = {
    '{{PAGE_LANG}}': cfg.page?.lang || 'zh-TW',
    '{{PAGE_MODE}}': cfg.page?.mode ? `data-mode="${cfg.page.mode}"` : '',
    '{{PAGE_TITLE}}': cfg.page?.title || '',
    '{{FAVICON}}': cfg.page?.favicon || '',
    '{{OG_TYPE}}': esc(og.type),
    '{{OG_TITLE}}': esc(og.title),
    '{{OG_DESCRIPTION}}': esc(og.description),
    '{{OG_IMAGE}}': og.image || '',
    '{{OG_URL}}': og.url || '',
    '{{OG_SITE_NAME}}': esc(og.siteName),
    '{{SIDEBAR_BRAND}}': sidebarBrand,
    '{{TOC_ITEMS}}': buildTocItems(sections),
    '{{HERO_BADGE}}': cfg.page?.badge || '',
    '{{HERO_TITLE}}': raw(cfg.page?.hero_title || cfg.page?.title || ''),
    '{{HERO_SUBTITLE}}': esc(cfg.page?.subtitle || ''),
    '{{HERO_AUTHOR}}': esc(heroAuthor),
    '{{HERO_NAV_ITEMS}}': navItems,
    '{{OPENING_QUOTE}}': buildQuote(cfg.quotes?.opening),
    '{{INSTRUCTOR_SECTION}}': buildInstructor(cfg),
    '{{CONTENT_SECTIONS}}': buildContentSections(sections, headerBlocks),
    '{{CLOSING_QUOTE}}': buildQuote(cfg.quotes?.closing),
    '{{FOOTER_SOCIAL_LINKS}}': buildFooterSocials(cfg),
    '{{FOOTER_COPYRIGHT}}': esc(cfg.footer?.copyright || ''),
    '{{SECTION_IDS}}': JSON.stringify(sectionIds),
    '{{ALL_ANCHOR_IDS}}': JSON.stringify(allAnchorIds),
    '{{BRANCH_TAGS}}': buildBranchTags(branchSegments),
  };

  for (const [key, val] of Object.entries(replacements)) {
    // 容許 formatter 在 {{ }} 內加空格，e.g. {{ SECTION_IDS }}
    const name = key.replace(/^\{\{/, '').replace(/\}\}$/, '');
    const pattern = new RegExp(`\\{\\{\\s*${name}\\s*\\}\\}`, 'g');
    html = html.replace(pattern, val);
  }

  html = embedLocalImages(html, courseDir);

  writeFileSync(outputPath, html, 'utf-8');
  console.log(`✅ Generated: ${outputPath}`);
  console.log(`   Sections: ${sections.length}, Sub-sections: ${sections.reduce((a, s) => a + s.subs.length, 0)}`);

  packageExamples(courseDir);
}

// ─── CLI (only when run directly, not when imported) ───

const __build_filename = fileURLToPath(import.meta.url);
if (resolve(process.argv[1]) === __build_filename) {
  const args = process.argv.slice(2);
  if (args.length < 1) {
    console.log('Usage:');
    console.log('  node build.mjs <course-dir>            # e.g. node build.mjs cake');
    console.log('  node build.mjs <course-dir>/content.md  # explicit content path');
    console.log('');
    console.log('Config layering:');
    console.log('  1. config/global.yaml     (base: instructor, socials, footer)');
    console.log('  2. <course-dir>/config.yaml  (override: page, quotes, nav)');
    process.exit(1);
  }

  let input = args[0];

  // Resolve course directory from input
  let courseDir;
  const resolved = resolve(input);

  if (existsSync(resolved) && statSync(resolved).isDirectory()) {
    courseDir = resolved;
  } else if (input.endsWith('.md')) {
    courseDir = dirname(resolved);
  } else {
    courseDir = resolved;
  }

  build(courseDir);
}
